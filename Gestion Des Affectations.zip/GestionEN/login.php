<?php
session_start();
require_once 'config/db.php';  #'../config/db.php';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();


    if ($user && password_verify($mot_de_passe, $user['mot_de_passe'])) {
        $_SESSION['user_id'] = $user['id_utilisateur'];
        $_SESSION['role_id'] = $user['role_id'];
        $_SESSION['nom'] = $user['nom'];
        $_SESSION['departement_id'] = $user['departement_id'];


        // Redirection selon le rôle
        switch ($user['role_id']) {
            case 1:
                header("Location: Admin/accueil.php");
                break;
            case 2:
                header("Location:  prof/accueil.php");
                break;
            case 3:
                header("Location: chef/accueil.php");
                break;
            case 4:
                header("Location: coord/accueil.php");
                break;
            case 5:
                header("Location: vacataire/accueil.php");
                break;
            default:
                $error = "Rôle inconnu.";
        }
        exit;
    } else {
        $error = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">

    <title>Connexion</title>
    <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', Arial, sans-serif;
    }

    body, html {
      height: 100%;
      width: 100%;
    }

    /* -------- Background animé -------- */
    body {
      min-height: 100vh;
      background: linear-gradient(120deg, #53be22 0%, #21c451 35%, #f0fff0 80%);
      background-size: 200% 200%;
      animation: moveBg 8s ease-in-out infinite;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    @keyframes moveBg {
      0% {background-position: 0 0;}
      50% {background-position: 100% 100%;}
      100% {background-position: 0 0;}
    }

    .ici {
      display: flex;
      flex-direction: row;
      height: 600px;
      width: 900px;
      background: rgba(255,255,255,0.13);
      border-radius: 20px;
      box-shadow: 0 8px 36px 0 rgba(83,190,34,0.13), 0 2px 8px rgba(0,0,0,0.11);
      overflow: hidden;
      backdrop-filter: blur(6px);
    }

    .left-section {
      width: 280px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(150deg, rgba(83,190,34,0.88) 70%, #21c451 100%);
      border-radius: 0 26px 26px 0;
      box-shadow: 4px 0 12px rgba(83,190,34,0.10);
    }

    .logo-container {
      text-align: center;
      color: white;
      width: 100%;
    }

    .logo {
      width: 140px;
      height: 140px;
      margin: auto;
      border-radius: 50%;
      background: linear-gradient(120deg, #fff 40%, #53be22 100%);
      box-shadow: 0 0 14px rgba(67,190,34,0.12);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }

    .logo img {
      width: 80px;
      height: 80px;
      object-fit: contain;
      filter: drop-shadow(0 2px 8px #21c451);
      transition: transform 0.3s;
    }
    .logo img:hover {
      transform: scale(1.07);
    }

    .right-section {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .login-form {
      width: 100%;
      max-width: 370px;
      background: rgba(255,255,255,0.41);
      padding: 2.5rem;
      border-radius: 16px;
      box-shadow: 0 8px 36px 0 rgba(67,190,34,0.11), 0 2px 8px rgba(0,0,0,0.12);
      backdrop-filter: blur(7px);
      position: relative;
    }
    .login-form::before {
      content: '';
      position: absolute;
      inset: 0;
      border-radius: 16px;
      pointer-events: none;
      background: linear-gradient(90deg,rgba(83,190,34,0.05) 0%,rgba(255,255,255,0.14) 100%);
      z-index: 0;
    }

    .login-form h2 {
      margin-bottom: 1.5rem;
      color: #21c451;
      text-align: center;
      font-weight: 700;
      font-size: 2.1rem;
      letter-spacing: 0.05em;
      position: relative;
      z-index: 1;
    }

    .form-group {
      margin-bottom: 1.5rem;
      position: relative;
      z-index: 1;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      color: #1b1b1b;
      font-weight: 500;
      letter-spacing: 0.01em;
    }

    .form-group input {
      width: 100%;
      padding: 13px 16px;
      border: 1px solid #21c451;
      border-radius: 7px;
      font-size: 1rem;
      background: rgba(255,255,255,0.87);
      transition: border 0.3s, box-shadow 0.3s;
      outline: none;
      box-shadow: 0 2px 8px rgba(67,190,34,0.08);
    }
    .form-group input:focus {
      border-color: #53be22;
      box-shadow: 0 2px 14px rgba(67,190,34,0.14);
    }

    .login-btn {
      width: 100%;
      padding: 14px;
      background: linear-gradient(90deg,#21c451 50%, #53be22 100%);
      color: white;
      border: none;
      border-radius: 7px;
      font-size: 1.15rem;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.3s, box-shadow 0.2s;
      margin-top: 0.6rem;
      box-shadow: 0 2px 8px rgba(67,190,34,0.10);
      position: relative;
      z-index: 1;
    }

    .login-btn:hover {
      background: linear-gradient(90deg,#53be22 40%, #21c451 100%);
      color: #fff;
      box-shadow: 0 4px 16px rgba(67,190,34,0.17);
      transform: translateY(-2px) scale(1.03);
    }
     .show-password {
    position: absolute;
    top: 10px;
    right: 0px;
    cursor: pointer;
    user-select: none;
    }
    .form-group {
        position: relative;
    }


    @media (max-width: 900px) {
      .ici {
        flex-direction: column;
        width: 98vw;
        min-width: 280px;
        height: auto;
      }
      .left-section {
        width: 100%;
        border-radius: 20px 20px 0 0;
        min-height: 160px;
        padding: 18px 0;
      }
      .right-section {
        padding: 1rem 0;
      }
    }

    @media (max-width: 600px) {
      .ici {
        width: 100vw;
        padding: 0;
      }
      .login-form {
        padding: 1rem;
        max-width: 97vw;
        border-radius: 10px;
      }
      .logo {
        width: 70px;
        height: 70px;
      }
      .logo img {
        width: 44px;
        height: 44px;
      }
    }
    </style>
</head>
<body>
 <div class="ici">
    <div class="left-section">
        <div class="logo-container">
            <div class="logo"><img src="images/logo.png" alt="Logo"></div>
        </div>
    </div>
    
    <div class="right-section">
        <form class="login-form" method="POST">
            <h2>Login</h2>
            
            <div class="form-group">
                <label for="email">Adresse Email</label>
                <input type="email" id="email" placeholder="Entrez votre email" name="email" required>
            </div>
            
            <div class="form-group" style="position:relative;">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" placeholder="Entrez votre mot de passe" name="mot_de_passe" required>
                <span class="show-password" onclick="togglePassword()" title="Afficher/Masquer le mot de passe">
                    <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="none" stroke="#21c451" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="position:absolute;top:39px;right:16px;cursor:pointer;">
                        <path d="M1 11C1 11 5 4 12 4s11 7 11 7-5 7-11 7S1 11 1 11z"/>
                        <circle cx="12" cy="11" r="3"/>
                    </svg>
                </span>
            </div>
            
            <button type="submit" class="login-btn">Se connecter</button>
        </form>
    </div>
 </div>

 <script>
function togglePassword() {
    var input = document.getElementById("password");
    var icon = document.getElementById("eyeIcon");

    if (input.type === "password") {
        input.type = "text";
        icon.innerHTML = '<path d="M1 11C1 11 5 4 12 4s11 7 11 7-5 7-11 7S1 11 1 11z"/><circle cx="12" cy="11" r="3"/><line x1="4" y1="4" x2="20" y2="20" stroke="#21c451" stroke-width="2"/>';
    } else {
        input.type = "password";
        icon.innerHTML = '<path d="M1 11C1 11 5 4 12 4s11 7 11 7-5 7-11 7S1 11 1 11z"/><circle cx="12" cy="11" r="3"/>';
    }
}
</script>
</html>