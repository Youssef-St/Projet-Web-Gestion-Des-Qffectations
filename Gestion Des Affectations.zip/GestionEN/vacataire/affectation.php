<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

$user_id = $_SESSION['user_id'];


// Récupérer les affectations des vacataire 
$affectations = $conn->prepare("
    SELECT a.id_affectation, a.id_utilisateur ,u.nom AS nom_prof, ue.nom AS nom_ue, a.annee_universitaire, a.statut, a.cours, a.td, a.tp, a.date_affectation, u.charge_horaire
    FROM affectations a
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
    JOIN unites_enseignement ue ON a.id_ue = ue.id_ue
    WHERE a.id_utilisateur = ? 
");
 $affectations->execute([$user_id]);
 $vac =  $affectations->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }


  .main-content {
    margin-left: 230px;
    width: 100%;
    height : 100%;
    transition: margin-left 0.3s ease;
    background-color: white;
}


  .sidebar.collapsed + .main-content {
      margin-left: 60px;
  }


        /*=======================================================================*/
                                           /*profile*/

:root {
  --primary: #27ae60;
  --primary-dark: #219150;
  --border: #e0e9e3;
  --radius: 16px;
  --shadow: 0 10px 32px rgba(39, 174, 96, 0.11), 0 2px 8px rgba(0,0,0,0.05);
}

body {
  font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
  background: linear-gradient(135deg, #e9f8ef 0%, #b6f0c2 100%);
  min-height: 100vh;
}

/* ------ CARD ------ */
.card {
  background: #fff;
  border: 1.5px solid var(--border);
  padding: 2.5rem 2rem;
  max-width: 780px;
  margin: 40px auto;
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  transition: box-shadow 0.2s;
}

.card:hover {
  box-shadow: 0 16px 48px rgba(39,174,96,0.14);
}

.header {
  display: flex;
  align-items: center;
  gap: 1.3rem;
  margin-bottom: 2.2rem;
}

.avatar {
  width: 76px;
  height: 76px;
  border: 2px solid var(--primary);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.96rem;
  background: linear-gradient(135deg, #e9f8ef 0%, #b6f0c2 120%);
  color: var(--primary-dark);
  box-shadow: 0 2px 10px rgba(39,174,96,0.12);
}

.card h1 {
  margin: 0;
  font-size: 1.6rem;
  color: var(--primary-dark);
  font-weight: 700;
  letter-spacing: 1.2px;
}

form {
  display: flex;
  flex-direction: column;
  gap: 32px;
}

div.a {
  width: 100%;
  min-height: 50px;
  background: linear-gradient(90deg, #e6fbe7 60%, #f7fff9 100%);
  border-radius: 8px;
  padding: 15px 18px;
  margin: 15px 0;
  box-shadow: 0 2px 8px rgba(39, 174, 96, 0.06);
  font-size: 1.07rem;
}

label {
  font-weight: 600;
  color: var(--primary-dark);
  margin-bottom: 6px;
}

input[type="text"],
input[type="number"],
input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 0.7rem 1rem;
  border: 1.5px solid var(--primary);
  border-radius: 12px;
  background: #fafff8;
  font-size: 1.08rem;
  margin-top: 6px;
  transition: border-color 0.2s, box-shadow 0.2s;
}

input:focus {
  border-color: var(--primary-dark);
  outline: none;
  box-shadow: 0 0 8px rgba(39, 174, 96, 0.15);
  background: #e9f8ef;
  color: #219150;
}

.dept-table {
  display: grid;
  grid-template-columns: 1fr 2fr;
  border: 1.5px solid var(--primary);
  margin: 1.5rem 0;
  border-radius: 8px;
  background: linear-gradient(90deg, #e6fbe7 60%, #f7fff9 100%);
  box-shadow: 0 2px 8px rgba(39, 174, 96, 0.07);
  overflow: hidden;
  min-height: 60px;
}

.dept-table div {
  padding: 1rem;
  border-right: 1.5px solid var(--border);
  font-size: 1.09rem;
  color: var(--primary-dark);
}
.dept-table div:last-child {
  border-right: none;
}

.divider, .barre1 {
  height: 2px;
  background: var(--primary);
  margin: 0px 0;
  border-radius: 3px;
  width: 100%;
  opacity: 0.2;
}

.mar input:focus {
  background: #27ae60;
  color: #fff;
}

.btn {
  padding: 0.85rem 1.4rem;
  min-width: 120px;
  background: linear-gradient(90deg, #27ae60 70%, #219150 100%);
  color: #fff;
  border-radius: 30px;
  border: none;
  cursor: pointer;
  font-size: 1.09rem;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(39,174,96,0.10);
  transition: background 0.23s, box-shadow 0.18s, transform 0.17s;
}

.btn:hover {
  background: linear-gradient(90deg, #219150 0%, #27ae60 100%);
  box-shadow: 0 4px 16px rgba(39,174,96,0.13);
  transform: scale(1.04);
  opacity: 0.95;
}

/* ------ TABLE MODERNE ------ */
.main-content h2 {
  text-align: center;
  font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
  color: var(--primary-dark);
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: 1px;
  margin-top: 38px;
  margin-bottom: 18px;
}

.table-container {
  width: 95%;
  margin: 0 auto 40px auto;
  max-height: 400px;
  overflow-y: auto;
  background: #fff;
  border-radius: 18px;
  box-shadow: var(--shadow);
  position: relative;
}

.table-container table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  border-radius: 15px;
  overflow: hidden;
}

.table-container thead {
  background: linear-gradient(90deg, #27ae60 0%, #219150 100%);
  color: white;
}

.table-container th, .table-container td {
  border: none;
  padding: 15px 10px;
  text-align: center;
  font-size: 1rem;
  transition: background 0.2s;
}

.table-container tbody tr {
  border-bottom: 2px solid #e3e3e3;
  transition: background 0.2s;
}

.table-container tbody tr:hover {
  background: #eafbe7;
  box-shadow: 0 2px 8px rgba(39, 174, 96, 0.07);
  cursor: pointer;
}

.table-container th {
  font-weight: 600;
  letter-spacing: 0.5px;
}

.table-container td {
  background: #f7fff9;
  color: #333;
}

.table-container td:last-child {
  border-right: none;
}

/* ------ Scrollbar verte personnalisée ------ */
.table-container::-webkit-scrollbar,
.card::-webkit-scrollbar {
  width: 10px;
  background: #e9f8ef;
  border-radius: 8px;
}
.table-container::-webkit-scrollbar-thumb,
.card::-webkit-scrollbar-thumb {
  background: #27ae60;
  border-radius: 8px;
}
.table-container::-webkit-scrollbar-thumb:hover,
.card::-webkit-scrollbar-thumb:hover {
  background: #219150;
}

/* ------ Responsive ------ */
@media (max-width: 900px) {
  .card, .table-container {
    padding: 12px 4px;
    border-radius: 12px;
  }
  .table-container th, .table-container td {
    padding: 8px 3px;
    font-size: 14px;
  }
}

@media (max-width: 650px) {
  .card, .table-container {
    max-width: 99%;
    padding: 8px 1px;
    border-radius: 10px;
  }
  .table-container table, .table-container thead, .table-container tbody, .table-container th, .table-container td, .table-container tr {
    display: block;
    width: 100%;
  }
  .table-container thead tr {
    display: none;
  }
  .table-container tbody tr {
    margin-bottom: 10px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(39,174,96,0.05);
  }
  .table-container td {
    position: relative;
    padding-left: 90px;
    border: none;
    border-bottom: 1px solid #eaeaea;
  }
  .table-container td[data-label]::before {
    content: attr(data-label);
    display: inline-block;
    position: absolute;
    left: 14px;
    top: 16px;
    font-size: 0.93rem;
    color: #27ae60;
    font-weight: bold;
  }
}

/* ------ Icones ------ */
.top-right-icon {
  position: absolute;
  top: 20px;
  right: 30px;
}

.top-right-icon img {
  width: 40px;
  height: 40px;
  cursor: pointer;
  transition: transform 0.3s;
}

.top-right-icon img:hover {
  transform: scale(1.2);
}

        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>

        <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 9l6 6 6-6"/>
      </svg>
      <a href="./affectation.php">Affectation</a>
    </li>
        <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h16"/>
        <path d="M12 2v16"/>
      </svg>
      <a href="./notes.php">Notes</a>
    </li>    
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
     
     
    <div class="main-content">
    <h2>Liste des Affectations</h2><br>
    <div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Professeur</th>
                <th>UE</th>
                <th>Année</th>
                <th>Statut</th>
                <th>Type</th>
                <th>Charge Horaire</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($vac as $aff): ?>
            <tr>
                <td><?= htmlspecialchars($aff['nom_prof']) ?></td>
                <td><?= htmlspecialchars($aff['nom_ue']) ?></td>
                <td><?= htmlspecialchars($aff['annee_universitaire']) ?></td>
                <td><?= htmlspecialchars($aff['statut']) ?></td>
                                <td>
                                    <?php
                                    $types = [];
                                    if ($aff['cours']) $types[] = 'Cours';
                                    if ($aff['td']) $types[] = 'TD';
                                    if ($aff['tp']) $types[] = 'TP';
                                    echo implode(' + ', $types);
                                    ?>
                                </td>   
                                 <td><?= htmlspecialchars($aff['charge_horaire']) ?>h</td>            
                                <td><?= htmlspecialchars($aff['date_affectation']) ?></td>
                
                    <form action="" method="POST" style="display:inline;">
                        <input type="hidden" name="id_affectation" value="<?= $aff['id_affectation'] ?>">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    </div>
    <script>

             function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
</body>
</html>
    
