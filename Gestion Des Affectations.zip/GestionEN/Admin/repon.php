<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

$id_utilisateurf = $_SESSION['user_id'];

// Récupération des rôles
$roles = $conn->query("SELECT * FROM roles")->fetchAll(PDO::FETCH_ASSOC);

// Récupération des filières
$filieres = $conn->query("SELECT * FROM filieres")->fetchAll(PDO::FETCH_ASSOC);

// Récupération des départements
$departements = $conn->query("SELECT * FROM departements")->fetchAll(PDO::FETCH_ASSOC);

// Récupération des utilisateurs avec jointures facultatives
$sql = "SELECT u.*, r.nom_role, f.nom_filiere, d.nomD
        FROM utilisateurs u
        LEFT JOIN roles r ON u.role_id = r.id_role
        LEFT JOIN filieres f ON u.filiere_id = f.id_filiere
        LEFT JOIN departements d ON u.departement_id = d.id_departement";

$utilisateurs = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&family=Montserrat:wght@600&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }




/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}
  .sidebar.collapsed + .main-content {
      margin-left: 60px;
  }


        /*=======================================================================*/
    

/* Main Card */
.main-card {
  background: linear-gradient(120deg, #f8fafc 75%, #e8f0fe 100%);
  border-radius: 1.4rem;
  box-shadow: 0 8px 32px rgba(44, 63, 150, 0.11), 0 1.5px 8px rgba(44, 150, 63, 0.09);
  padding: 2.7rem 2.3rem 2.2rem 2.3rem;
  margin: 2.2rem auto;
  max-width: 98vw;
  font-family: 'Inter', 'Montserrat', Arial, sans-serif;
}

/* Titre moderne */
h3 {
  color: #108fe3;
  font-weight: 700;
  font-family: 'Montserrat', 'Inter', Arial, sans-serif;
  text-align: center;
  margin-bottom: 2.2rem;
  font-size: 1.5rem;
  letter-spacing: 0.02em;
  background: linear-gradient(90deg, #108fe3 70%, #25c16f 110%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* Table */
.table-responsive {
  border-radius: 1.2rem;
  overflow-x: auto;
}
.table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  background: transparent;
  font-family: 'Inter', Arial, sans-serif;
}
.table thead tr th {
  background: #eaf6fb !important;
  color: #108fe3 !important;
  font-weight: 600;
  font-size: 1.1rem;
  border: none;
  letter-spacing: 0.01em;
  padding: 18px 0;
  text-align: center;
}
.table tbody tr {
  transition: box-shadow 0.18s;
}
.table tbody tr:hover {
  background-color: #f2f9ff;
  box-shadow: 0 2px 10px rgba(44, 63, 150, 0.08);
}

/* Cellules */
td, th {
  vertical-align: middle !important;
  padding: 12px 8px !important;
  border: none;
}

/* Nom + Email stylé */
.table td {
  font-size: 1.08rem;
  color: #283b4d;
}
.table td.text-muted {
  color: #6c778d !important;
  font-size: 1rem;
}

/* Select custom */
.form-select {
  border-radius: 0.7rem;
  border: 1.2px solid #108fe3;
  padding: 6px 14px;
  font-size: 1.05rem;
  background: #f6fafd;
  color: #108fe3;
  font-weight: 500;
  transition: border-color 0.18s;
  box-shadow: 0 1px 2px rgba(44, 63, 150, 0.04);
}
.form-select:focus {
  border-color: #25c16f;
  background: #eaf3fb;
  outline: none;
}

/* Bouton moderne */
.btn-enregistrer, .btn-outline-success, .btn {
  border-radius: 20px;
  font-weight: 600;
  padding: 7px 18px;
  font-size: 1.08rem;
  background: linear-gradient(90deg, #25c16f 60%, #108fe3 120%);
  color: #fff !important;
  border: none;
  box-shadow: 0 2px 12px rgba(44, 150, 63, 0.12);
  transition: background 0.18s, box-shadow 0.18s;
  cursor: pointer;
}
.btn-enregistrer:hover, .btn-outline-success:hover, .btn:hover {
  background: linear-gradient(90deg, #108fe3 60%, #25c16f 120%);
  box-shadow: 0 4px 18px rgba(44, 150, 63, 0.18);
  color: #fff;
}

/* Icônes dans th et td */
th, td {
  font-family: 'Inter', Arial, sans-serif;
}
th .icon {
  font-size: 1.13rem;
  margin-right: 5px;
  vertical-align: middle;
}
td .icon {
  font-size: 1.12rem;
  color: #25c16f;
  margin-right: 4px;
  vertical-align: middle;
}

/* Responsive Table */
@media (max-width: 900px) {
  .main-card {
    padding: 1rem 0.3rem;
  }
  .table thead tr th,
  .table td {
    font-size: 0.98rem !important;
    padding: 10px 2px !important;
  }
  .form-select {
    font-size: 0.97rem;
    padding: 5px 10px;
  }
}

/* Animation apparitions */
@keyframes popupFade {
  0% { opacity: 0; transform: scale(0.96) translateY(24px);}
  100% { opacity: 1; transform: scale(1) translateY(0);}
}
.main-card, .table-responsive, .table {
  animation: popupFade 0.27s cubic-bezier(.57,1.53,.54,.93);
}
    </style>
</head>
<body>
   
  <div class="sidebar" id="sidebar">
    <button class="toggle-button" onclick="toggleSidebar()">
      <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg"  width="24" height="24" fill="none"
           stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
        <path id="toggleArrow" d="M9 3v18"/>
      </svg>
    </button>

    <div class="logo-container">
      <div class="logo">
        <a href="./accueil.php">
          <img src="../images/logo1.png" alt="logo">
        </a>
      </div>
    </div>

    <ul class="menu">
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 9l9-7 9 7"/>
          <path d="M9 22V12h6v10"/>
        </svg>
        <a href="./accueil.php">Accueil</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="7" r="4"/>
          <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
        </svg>
        <a href="./comtp.php">Compte Professeur</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
          <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
          <path d="M9 10h6"/>
          <path d="M9 14h6"/>
        </svg>
        <a href="./repon.php">Responsabilités</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
          <polyline points="16 17 21 12 16 7"/>
          <line x1="21" y1="12" x2="9" y2="12"/>
        </svg>
        <a href="../login.php">Déconnexion</a>
      </li>
    </ul>
  </div>

    
     
<div class="main-content">
    <div class="main-card">
        <h3 class="">👥 Gestion des responsabilités</h3>
        
        <div class="table-responsive">
            <table class="table align-middle text-center">
                <thead class="table-light">
                    <tr class="align-middle">
                        <th>👤 Nom</th>
                        <th>📧 Email</th>
                        <th>🎓 Rôle</th>
                        <th>🏫 Filière / Département</th>
                        <th>✅ Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($utilisateurs as $user): ?>
                    <tr>
                        <form method="POST" action="update_role.php" class="row g-2 align-items-center justify-content-center">
                            <input type="hidden" name="user_id" value="<?= $user['id_utilisateur'] ?>">
                            
                            <td><?= htmlspecialchars($user['nom'] . ' ' . $user['prenom']) ?></td>
                            <td class="text-muted"><?= htmlspecialchars($user['email']) ?></td>
                            <td>
                                <select name="role_id" class="form-select form-select-sm border-primary role-select" onchange="toggleSelects(this)">
                                    <?php foreach ($roles as $role): ?>
                                    <option value="<?= $role['id_role'] ?>" <?= $user['role_id'] == $role['id_role'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($role['nom_role']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <!-- Filière (role_id = 4 = COORDONNATEUR) -->
                                <select name="filiere_id" class="form-select form-select-sm filiere-select mb-2" 
                                    style="<?= $user['role_id'] == 4 ? '' : 'display:none;' ?>">
                                    <option value="">-- Choisir une filière --</option>
                                    <?php foreach ($filieres as $filiere): ?>
                                    <option value="<?= $filiere['id_filiere'] ?>" <?= $user['filiere_id'] == $filiere['id_filiere'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($filiere['nom_filiere']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>

                                <!-- Département (role_id = 3 = CHEF) -->
                                <select name="departement_id" class="form-select form-select-sm departement-select" 
                                    style="<?= $user['role_id'] == 3 ? '' : 'display:none;' ?>">
                                    <option value="">-- Choisir un département --</option>
                                    <?php foreach ($departements as $departement): ?>
                                    <option value="<?= $departement['id_departement'] ?>" <?= $user['departement_id'] == $departement['id_departement'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($departement['nomD']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <button type="submit" class="btn btn-sm btn-outline-success rounded-pill px-3">💾 Enregistrer</button>
                            </td>
                        </form>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>




<script>
        function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }

    
function toggleSelects(select) {
    const row = select.closest('tr');
    const role = parseInt(select.value);
    const filiereSelect = row.querySelector('.filiere-select');
    const departementSelect = row.querySelector('.departement-select');

    if (role === 4) { // Coordonnateur
        filiereSelect.style.display = '';
        departementSelect.style.display = 'none';
    } else if (role === 3) { // Chef
        filiereSelect.style.display = 'none';
        departementSelect.style.display = '';
    } else {
        filiereSelect.style.display = 'none';
        departementSelect.style.display = 'none';
    }
}
</script>




  
</body>
</html>

