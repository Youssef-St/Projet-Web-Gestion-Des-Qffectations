<?php
require_once '../config/db.php';

$userId = $_POST['user_id'];
$roleId = $_POST['role_id'];
$filiereId = $_POST['filiere_id'] ?? null;
$departementId = $_POST['departement_id'] ?? null;

// Mise à jour du rôle + filière ou département selon le rôle
$sql = "UPDATE utilisateurs 
        SET role_id = :role_id, 
            filiere_id = :filiere_id, 
            departement_id = :departement_id 
        WHERE id_utilisateur = :user_id";

$stmt = $conn->prepare($sql);
$stmt->execute([
    ':role_id' => $roleId,
    ':filiere_id' => $roleId == 4 ? $filiereId : null, // 4 = coordonnateur
    ':departement_id' => $roleId == 3 ? $departementId : null, // 3 = chef
    ':user_id' => $userId
]);


header("Location: repon.php");
exit;
?>