<?php
// Import PHPMailer classes en haut du fichier
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

// Traitement création compte
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'ajouter') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mot_de_passe_clair = $_POST['password'];

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $departement_id = $_POST['departement'];
    $specialite = $_POST['specialite'];

    
    // Vérifier doublon
    $check = $conn->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $check->execute([$email]);

    if ($check->rowCount() > 0) {
        $_SESSION['message'] = "❌ Un utilisateur avec cet email existe déjà.";
    } else {
        $stmt = $conn->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe , role_id, departement_id, specialite) 
                                VALUES (?, ?, ?, ?, 2, ?, ?)");
        $stmt->execute([$nom, $prenom, $email, $password, $departement_id, $specialite]);
        $_SESSION['message'] = "✅ Compte professeur créé avec succès.";

       $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ystitou18@gmail.com';
        $mail->Password   = 'xozo zrzn bzhh rixw'; // mot de passe d'application Gmail
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        $mail->setFrom('ystitou18@gmail.com', 'Administration');
        $mail->addAddress($email, $prenom . ' ' . $nom); // <- ici $email est bien défini

        $mail->isHTML(true);
        $mail->Subject = 'Création de votre compte';
        $mail->Body = "
            <p>Bonjour cher professeur,</p>
            <p>Votre compte a été créé avec succès.</p>
            <p>Mot de passe temporaire : <b>$mot_de_passe_clair</b></p>
            <p>Merci de le modifier dès la première connexion.</p>
            <p>Cordialement,<br>Administration</p>
        ";

        $mail->AltBody = "Bonjour, votre compte vacataire a été créé. Mot de passe : $mot_de_passe_clair";

        $mail->send();

    }

     header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
  

// Récupérer les professeurs existants
$profs = $conn->query("
    SELECT u.nom, u.prenom, u.email, d.nomD AS departement, u.specialite
    FROM utilisateurs u
    JOIN departements d ON d.id_departement = u.departement_id

")->fetchAll();

$departements = $conn->query("
    SELECT nomD, id_departement
    FROM departements

")->fetchAll();

?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>


    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }



    .main-content {
      flex-grow: 1;
      margin-left: 230px;
      padding: 30px;
      background-color: #ffffff;
      min-height: 100vh;
      transition: margin-left 0.3s;
    }

    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }


/* ===== MAIN CONTENT ===== */


    
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }

        .top-right-icon {
            position: absolute;
            top: 20px;
            right: 30px;
            }

        .top-right-icon img {
            width: 40px;
            height: 40px;
            cursor: pointer;
            transition: transform 0s;
            }

        .top-right-icon img:hover {
            transform: scale(1.2);

        }


        
    </style>
</head>
<body >
   
  <div class="sidebar" id="sidebar">
    <button class="toggle-button" onclick="toggleSidebar()">
      <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg"  width="24" height="24" fill="none"
           stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
        <path id="toggleArrow" d="M9 3v18"/>
      </svg>
    </button>

    <div class="logo-container">
      <div class="logo">
        <a href="./accueil.php">
          <img src="../images/logo1.png" alt="logo">
        </a>
      </div>
    </div>

    <ul class="menu">
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 9l9-7 9 7"/>
          <path d="M9 22V12h6v10"/>
        </svg>
        <a href="./accueil.php">Accueil</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="7" r="4"/>
          <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
        </svg>
        <a href="./comtp.php">Compte Professeur</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
          <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
          <path d="M9 10h6"/>
          <path d="M9 14h6"/>
        </svg>
        <a href="./repon.php">Responsabilités</a>
      </li>
      <li>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
             stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
          <polyline points="16 17 21 12 16 7"/>
          <line x1="21" y1="12" x2="9" y2="12"/>
        </svg>
        <a href="../login.php">Déconnexion</a>
      </li>
    </ul>
  </div>
     

<div class="main-content">
     <div class="max-w-6xl mx-auto py-10 px-4">
    <div class="text-center mb-10">
      <h1 class="text-4xl font-bold text-indigo-600 mb-2 flex justify-center items-center gap-2">
        👩‍🏫 Création de comptes professeurs
      </h1>
      <p class="text-gray-600 text-lg">Ajoutez des professeurs à la plateforme avec leurs informations complètes.</p>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
      <div class="bg-blue-100 text-blue-800 p-4 rounded-md mb-6 shadow-sm text-center font-medium">
        <?= $_SESSION['message']; unset($_SESSION['message']); ?>
      </div>
    <?php endif; ?>

    <!-- Formulaire -->
    <form action="" method="POST" class="bg-white shadow-md rounded-xl p-8 space-y-6 max-w-3xl mx-auto border border-gray-200">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label class="block text-sm font-medium text-gray-700">Nom</label>
          <input type="text" name="nom" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">Prénom</label>
          <input type="text" name="prenom" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">Email</label>
          <input type="email" name="email" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">Mot de passe</label>
          <input type="password" name="password" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">Département</label>
          <select name="departement" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
            <option value="">-- Choisir --</option>
            <?php foreach ($departements as $dep): ?>
              <option value="<?= $dep['id_departement'] ?>"><?= htmlspecialchars($dep['nomD']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">Spécialité</label>
          <input type="text" name="specialite" required class="mt-1 block w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
        </div>
      </div>
      <input type="hidden" name="action" value="ajouter">

      <div class="text-right">
        <button type="submit" name="ajouter" class="inline-flex items-center gap-2 bg-indigo-600 text-white font-medium py-2 px-5 rounded-lg hover:bg-indigo-700 transition shadow">
          ➕ Ajouter professeur
        </button>
      </div>
    </form>

    <!-- Table des professeurs -->
    <div class="mt-12 bg-white shadow-md rounded-xl p-6 overflow-x-auto border border-gray-200">
      <h2 class="text-2xl font-semibold mb-4 text-gray-700">📋 Liste des professeurs</h2>
      <table class="min-w-full table-auto text-sm text-left">
        <thead class="bg-gray-100 text-gray-700">
          <tr>
            <th class="px-4 py-2">Nom</th>
            <th class="px-4 py-2">Email</th>
            <th class="px-4 py-2">Département</th>
            <th class="px-4 py-2">Spécialité</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
          <?php foreach ($profs as $p): ?>
            <tr class="hover:bg-gray-50">
              <td class="px-4 py-2"><?= htmlspecialchars($p['nom'] . ' ' . $p['prenom']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($p['email']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($p['departement']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($p['specialite']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>


 </div>
    <script>
         function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }

    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
  </script>

  
</body>
</html>

