<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

$id_utilisateurf = $_SESSION['user_id'];
$departement_id = $_SESSION['departement_id'];

$stmt = $conn->prepare("
    SELECT COUNT(*) FROM fichiers f
    WHERE NOT EXISTS (
        SELECT 1 FROM fichiers_vus fv
        WHERE fv.id_fichier = f.id AND fv.id_utilisateur = ?
    )
");
$stmt->execute([$id_utilisateurf]);
$nouveauxFichiers = $stmt->fetchColumn();



// Récupérer les informations du prof
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT u.nom, u.prenom, u.email, u.departement_id, d.nomD , u.charge_horaire , r.nom_role
    FROM utilisateurs u
    JOIN departements d ON u.departement_id = d.id_departement
    JOIN roles r  ON u.role_id = r.id_role
    WHERE u.id_utilisateur = ?
");
$stmt->execute([$user_id]);
$prof = $stmt->fetch();
if ($prof) {
    $_SESSION['nom_utilisateurt'] = $prof['prenom'] . ' ' . $prof['nom'];
} else {
    // Affichage d'un message d'erreur utile
    echo "<div style='color: red; font-weight: bold;'>Erreur : professeur non trouvé dans la base de données.</div>";
}

// Comptages
$Module = $conn->query("SELECT COUNT(*) FROM unites_enseignement")->fetchColumn();

$stmt = $conn->prepare("SELECT COUNT(*) FROM affectations WHERE id_utilisateur = ?");
$stmt->execute([$id_utilisateurf]);
$nbAffectation = $stmt->fetchColumn();

$req = $conn->query("SELECT d.nomD AS departement, COUNT(f.id_filiere) AS total
                     FROM departements d
                     LEFT JOIN filieres f ON d.id_departement = f.departement_id
                     GROUP BY d.nomD");

$labels = [];
$values = [];

while ($row = $req->fetch()) {
    $labels[] = $row['departement'];
    $values[] = $row['total'];
}


$req2 = $conn->query("SELECT DATE(date_connexion) AS jour, COUNT(*) AS total
                      FROM connexions
                      GROUP BY jour ORDER BY jour DESC LIMIT 7");

$jours = [];
$totaux = [];

while ($row = $req2->fetch()) {
    $jours[] = $row['jour'];
    $totaux[] = $row['total'];
}


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



  .main-content {
    margin-left: 230px;
    width: 100%;
    height : 100%;
    transition: margin-left 0.3s ease;
    background-color: white;
}


  .sidebar.collapsed + .main-content {
      margin-left: 60px;
  }


        /*=========================================================*/




.header {
  height: 80px;
  background: #fff;
  box-shadow: 0 3px 24px rgba(60, 60, 120, 0.07);
  padding: 0 2.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
}

/* === Partie gauche === */
.left-section .search-bar {
  position: relative;
  display: flex;
  align-items: center;
}

.left-section .search-input {
  padding: 10px 38px 10px 18px; /* espace à droite pour l’icône */
  font-size: 1.05rem;
  border: none;
  border-radius: 8px;
  background: #f3f6fa;
  box-shadow: 0 1px 2px rgba(60, 60, 120, 0.04);
  transition: background 0.18s, box-shadow 0.18s;
  outline: none;
  width: 300px;
}

.left-section .search-input:focus {
  background: #eaf3fb;
  box-shadow: 0 2px 6px rgba(80, 120, 220, 0.12);
}

.search-bar .search-icon {
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  display: flex;
  align-items: center;
  justify-content: center;
}

.search-bar .search-icon svg {
  width: 20px;
  height: 20px;
  stroke: #6373a7;
}

/* === Partie droite === */
.right-section {
  display: flex;
  align-items: center;
  gap: 2rem;
}

/* Icône cloche */
.icon img {
  width: 28px;
  height: 28px;
  cursor: pointer;
  filter: grayscale(0.8) brightness(0.8);
  transition: filter 0.15s;
}

.icon img:hover {
  filter: none;
}

/* Barre séparatrice */
.separator {
  width: 2px;
  height: 38px;
  background: linear-gradient(to bottom, #eaeaea 20%, #b9c0d6 80%);
  border-radius: 2px;
}

/* Profil */
.profile {
  display: flex;
  align-items: center;
  gap: 0.7rem;
  position: relative;
  cursor: pointer;
  padding: 2px 8px;
  border-radius: 10px;
  transition: background 0.18s;
}

.profile:hover, .profile:focus-within {
  background: #f3f7fd;
}

/* Avatar stylé */
.avatar {
  width: 42px;
  height: 42px;
  border: 2px solid #2ecc71;
  border-radius: 50%;
  overflow: hidden;
  background-color: #f8f8f8;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 1px 8px rgba(80, 220, 160, 0.06);
}

.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* Profil texte moderne */
.profile-text {
  font-size: 1.07rem;
  font-weight: 500;
  color: #1a1e2e;
  letter-spacing: 0.01em;
}

/* Menu déroulant moderne */
.menu-profil {
  display: none;
  position: absolute;
  top: 52px;
  right: 0;
  background-color: #fff;
  border: none;
  box-shadow: 0 8px 40px rgba(60, 60, 120, 0.16);
  border-radius: 12px;
  z-index: 1000;
  min-width: 210px;
  animation: fadeIn 0.18s;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-12px);}
  to { opacity: 1; transform: translateY(0);}
}

.menu-profil ul {
  list-style: none;
  margin: 0;
  padding: 8px 0;
}

.menu-profil li {
  padding: 0;
}

.menu-profil li a {
  text-decoration: none;
  color: #21284a;
  display: block;
  padding: 13px 24px;
  font-size: 1.01rem;
  font-weight: 500;
  border-radius: 8px;
  transition: background 0.17s, color 0.17s;
}

.menu-profil li a:hover {
  background: #eaf3fb;
  color: #218c74;
}

/* Afficher le menu au survol de .profile */
.profile:hover .menu-profil,
.profile:focus-within .menu-profil {
  display: block;
}

/* Overlay flou et sombre */
.modal-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(33, 38, 72, 0.17);
  z-index: 2000;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.18s;
  backdrop-filter: blur(2px);
}

/* Carte centrale moderne */
.modal-card {
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 8px 32px rgba(60, 60, 120, 0.18);
  padding: 2.2rem 2.7rem 2rem 2.7rem;
  min-width: 400px;
  max-width: 95vw;
  font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* Titre stylé */
.modal-card h2 {
  color: #24344d;
  font-size: 1.6rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  letter-spacing: 0.02em;
}

/* Formulaire vertical et espacé */
.modal-card form {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 1.1rem;
}

/* Label moderne */
.modal-card label {
  color: #24344d;
  font-size: 1.08rem;
  font-weight: 500;
  margin-bottom: 0.3rem;
}

/* Champ de saisie moderne */
.modal-input {
  width: 100%;
  padding: 11px 16px;
  font-size: 1.08rem;
  border: none;
  background: #f7f9fb;
  border-radius: 7px;
  margin-bottom: 0.2rem;
  box-shadow: 0 1px 2px rgba(60, 60, 120, 0.03);
  outline: none;
  transition: background 0.15s, box-shadow 0.15s;
}

.modal-input:focus {
  background: #eaf3fb;
  box-shadow: 0 2px 6px rgba(80, 120, 220, 0.11);
}

/* Bouton moderne */
.modal-btn {
  margin-top: 1.2rem;
  padding: 12px 38px;
  background: #07ca60;
  color: #fff;
  font-weight: 700;
  font-size: 1.09rem;
  border: none;
  border-radius: 9px;
  box-shadow: 0 3px 12px rgba(39, 198, 115, 0.13);
  cursor: pointer;
  transition: background 0.13s, box-shadow 0.13s;
}

.modal-btn:hover {
  background: #04ad4e;
  box-shadow: 0 4px 18px rgba(39, 198, 115, 0.18);
}

.count {
  display: flex;
  gap: 20px;
  margin: 20px;
  justify-content: space-around;
  flex-wrap: wrap;
}
.card {
  background-color: #f5f5f5;
  border-left: 5px solid #139608ff;
  border-radius: 8px;
  padding: 20px;
  width: 220px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  font-family: sans-serif;
}
.card h2 {
  margin: 0;
  font-size: 36px;
  color: #139608ff;
}
.card p {
  margin-top: 5px;
  font-size: 16px;
  color: #555;
  font-family: 'Montserrat', 'Roboto', Arial, sans-serif;
}

/* Overlay flou et élégant */
.overlay {
  display: none;
  position: fixed;
  top: 0; left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(39,51,89,0.13);
  justify-content: center;
  align-items: center;
  z-index: 9999;
  backdrop-filter: blur(2px);
}

/* Carte profil moderne & animée */
.profile-card-modern {
  background: linear-gradient(115deg, #f9fbfc 80%, #eef4fa 100%);
  padding: 38px 34px 32px 34px;
  border-radius: 22px;
  box-shadow: 0 10px 40px rgba(44, 63, 150, 0.15), 0 1.5px 6px rgba(80, 180, 220, 0.08);
  min-width: 350px;
  max-width: 95vw;
  font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
  position: relative;
  animation: popupFade 0.28s cubic-bezier(.57,1.53,.54,.93);
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* Avatar utilisateur stylé */
.profile-card-modern .profile-avatar {
  width: 72px;
  height: 72px;
  border-radius: 50%;
  object-fit: cover;
  box-shadow: 0 2px 8px rgba(44, 63, 150, 0.10);
  border: 2.2px solid #2ecc71;
  margin-bottom: 18px;
  background: #f1f5fa;
  display: block;
}

/* Bouton de fermeture rond et moderne */
.close-btn {
  position: absolute;
  top: 18px;
  right: 20px;
  width: 34px;
  height: 34px;
  background: #f5f8fc;
  border-radius: 50%;
  font-size: 1.5rem;
  color: #5069b4;
  border: none;
  box-shadow: 0 1px 6px rgba(60,60,120,0.07);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.18s, color 0.18s;
  z-index: 1;
}
.close-btn:hover {
  background: #eaf3fb;
  color: #218c74;
}

/* Titre profil */
.profile-card-modern h2 {
  text-align: center;
  margin-bottom: 8px;
  font-weight: 700;
  font-size: 1.37rem;
  color: #23314e;
  letter-spacing: 0.01em;
}

/* Infos utilisateur séparées et modernes */
.profile-card-modern .profile-info-list {
  width: 100%;
  margin-top: 12px;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
.profile-card-modern .profile-info-item {
  display: flex;
  align-items: center;
  padding: 0.4rem 0;
  border-radius: 6px;
  background: transparent;
  font-size: 1.09rem;
  color: #29364e;
}
.profile-card-modern .profile-info-label {
  min-width: 120px;
  font-weight: 600;
  color: #218c74;
  margin-right: 0.7rem;
  font-size: 1.04rem;
}
.profile-card-modern .profile-info-value {
  font-weight: 400;
  color: #24344d;
  font-size: 1.05rem;
  letter-spacing: 0.01em;
}

@keyframes fadeIn {
  from { opacity: 0;}
  to { opacity: 1;}
}

/* Responsive pour petit écran */
@media (max-width: 500px) {
  .modal-card {
    min-width: 90vw;
    padding: 1.2rem 1rem;
  }
  .modal-btn {
    width: 100%;
    padding: 11px 0;
  }
}  
        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
        <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" ry="2"/>
        <path d="M8 2v4"/>
      </svg>
      <a href="./ue.php">Unités d'enseignement</a>
    </li>

    <li>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M9 11l3 3L22 4"/>
    <path d="M2 5h6"/>
    <path d="M2 10h6"/>
    <path d="M2 15h6"/>
  </svg>
  <a href="./souhait.php" class="a_items">Souhaite</a>
</li>

    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="historique.php">Historique</a>
    </li>

    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
     
    <div class="main-content">
        <div class="header">
          <!-- Zone gauche : recherche -->
          <div class="left-section">
              <input type="text" class="search-input" placeholder="recherche">
              <span class="search-icon">
                <!-- Utilise une icône SVG moderne -->
                <svg width="20" height="20" fill="none" stroke="#6373a7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="9" cy="9" r="7"/>
                  <line x1="15" y1="15" x2="19" y2="19"/>
                </svg>
              </span>      
          </div>

          <!-- Zone droite : cloche + séparateur + profil -->
          <div class="right-section">
            <div class="icon">
              <img src="../images/cloche.png" alt="Notification" title="Notification">
            </div>

            <div class="separator"></div>

            <div class="profile">
              <div class="avatar">
                <img src="../images/profil.jpg" alt="photo">
              </div>
              <span class="profile-text"><?php echo htmlspecialchars($prof['nom_role']); ?></span>
              <!-- MENU DEROULANT -->
              <div class="menu-profil">
                <ul>
                  <li><a href="#" class="profileCard" onclick="toggleProfileCard(event)">Afficher le profil</a></li>
                  <li><a href="#" class="change-password-link">Changer le mot de passe</a></li>           
                </ul>
              </div>
            </div>
          </div>
        </div>


          <div class="profile-container">

            <div id="profileOverlay" class="overlay">
              <div class="profile-card-modern">
                <button class="close-btn" onclick="toggleProfileCard()">&times;</button>
                <img src="../images/profil.jpg" alt="Avatar" class="profile-avatar">
                <h2>Profil utilisateur</h2>
                <div class="profile-info-list">
                  <div class="profile-info-item">
                    <span class="profile-info-label">Nom :</span>
                    <?php echo htmlspecialchars($prof['nom']); ?>
                  </div>
                  <div class="profile-info-item">
                    <span class="profile-info-label">Prénom :</span>
                    <?php echo htmlspecialchars($prof['prenom']); ?>
                  </div>
                  <div class="profile-info-item">
                    <span class="profile-info-label">Email :</span>
                    <?php echo htmlspecialchars($prof['email']); ?>
                  </div>
                  <div class="profile-info-item">
                    <span class="profile-info-label">ID :</span>
                    <?php echo htmlspecialchars($user_id); ?>
                  </div>
                  <div class="profile-info-item">
                    <span class="profile-info-label">Département :</span>
                    <?php echo htmlspecialchars($prof['nomD']); ?>
                  </div>
                  <div class="profile-info-item">
                    <span class="profile-info-label">ID Département :</span>
                    <?php echo htmlspecialchars($prof['departement_id']); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>


                <!-- Partie changement de mot de passe -->
                <div class="modal-overlay" id="modalPassOverlay" style="display:none;">
                  <div class="modal-card">
                    <h2>Changer le mot de passe&nbsp;:</h2>
                    <form method="POST">
                      <label for="oldPass">Ancien mot de passe&nbsp;:</label>
                      <input type="password" id="oldPass" class="modal-input" name="old-pass" autocomplete="current-password">

                      <label for="newPass">Nouveau mot de passe&nbsp;:</label>
                      <input type="password" id="newPass" class="modal-input" name="new-pass" autocomplete="new-password">

                      <button type="submit" class="modal-btn">Enregistrer</button>
                    </form>
                  </div>
                </div>
                               
                <?php


                    // Vérifier si le formulaire est soumis
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $user_id = $_SESSION['user_id'];
                        $old_pass = $_POST['old-pass'];
                        $new_pass = $_POST['new-pass'];

                        // Récupérer l'ancien mot de passe depuis la base
                        $stmt = $conn->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id_utilisateur = ?");
                        $stmt->execute([$user_id]);
                        $user = $stmt->fetch();

                        if ($user && password_verify($old_pass, $user['mot_de_passe'])) {
                            // L'ancien mot de passe est correct
                            $new_pass_hashed = password_hash($new_pass, PASSWORD_DEFAULT);

                            // Mise à jour du nouveau mot de passe
                            $update = $conn->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id_utilisateur = ?");
                            $update->execute([$new_pass_hashed, $user_id]);

                            echo "<br> Mot de passe mis à jour avec succès ✅.";
                        } else {
                            echo "<br> Ancien mot de passe incorrect ❌.";
                        }
                    }
                  ?>

                

                  <div class = "count">
                      <div class="card">
                        <h2><?= $nbAffectation ?></h2>
                        <p>Affectation</p>
                      </div>
                      <div class="card">
                        <h2><?= $Module ?></h2>
                        <p>Module</p>
                      </div>                      
                      <div class="card">
                        <h2><?= $prof['charge_horaire']?></h2>
                        <p>Charge Horaire</p>
                      </div>
                  </div> 


                  <div style="display: flex; flex-wrap: wrap; justify-content: space-around; margin-top: 150px; margin-bottom: 70px;">
                      <div style="width: 45%; min-width: 300px;">
                        <canvas id="chartModule"></canvas>
                      </div>
                      <div style="width: 45%; min-width: 300px;">
                        <canvas id="chartConnexions"></canvas>
                      </div>
                  </div>

    </div>

    <script>
           function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }



    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });


      function toggleProfileCard(event) {
    if (event) event.preventDefault();
    const overlay = document.getElementById('profileOverlay');
    if (overlay.style.display === 'flex') {
      overlay.style.display = 'none';
    } else {
      overlay.style.display = 'flex';
    }
  }

    // Ouvre la modale quand on clique sur "Changer le mot de passe"
    document.querySelectorAll('.change-password-link').forEach(function(link) {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('modalPassOverlay').style.display = 'flex';
      });
    });
    // Fermer la modale si on clique en dehors de la carte
    document.getElementById('modalPassOverlay').addEventListener('click', function(e) {
      if(e.target === this) this.style.display = 'none';
    });


    const ctx1 = document.getElementById('chartModule').getContext('2d');
    new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Filières par Département',
            data: <?= json_encode($values) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});

  const ctx2 = document.getElementById('chartConnexions').getContext('2d');
  new Chart(ctx2, {
      type: 'line',
      data: {
          labels: <?= json_encode($jours) ?>,
          datasets: [{
              label: 'Connexions récentes',
              data: <?= json_encode($totaux) ?>,
              fill: true,
              borderColor: 'rgb(75, 192, 192)',
              tension: 0.3
          }]
      },
      options: {
          scales: {
              y: { beginAtZero: true }
          }
      }
  });

</script>
</body>
</html>
    
