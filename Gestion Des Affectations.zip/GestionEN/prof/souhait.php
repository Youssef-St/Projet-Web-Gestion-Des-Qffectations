<?php
session_start();
require_once '../config/db.php';



$departement_id = $_SESSION['departement_id'];


// Connexion DB déjà établie
$stmt = $conn->prepare("SELECT actif, date_limite FROM parametres_choix WHERE id_departement = ?");
$stmt->execute([$_SESSION['departement_id']]);
$param = $stmt->fetch();

$choix_actif = $param ? (bool)$param['actif'] : false;
$date_limite = $param && $param['date_limite'] ? date('d/m/Y à H:i', strtotime($param['date_limite'])) : null;




if (!isset($_SESSION['user_id'])) {
    die("Utilisateur non connecté.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_utilisateur = $_SESSION['user_id'];
    $annee_universitaire = date("Y") . "-" . (date("Y") + 1);
    $charge_totale = 0;



    if (isset($_POST['ue_ids']) && is_array($_POST['ue_ids'])) {
        $ordre_preferences = $_POST['ordre_preference'] ?? [];
        $ordre = 1;

        foreach ($_POST['ue_ids'] as $id_ue) {
            $types = $_POST['type_affectation'][$id_ue] ?? [];

            $cours = isset($types['cours']) ? 1 : 0;
            $td    = isset($types['td'])    ? 1 : 0;
            $tp    = isset($types['tp'])    ? 1 : 0;

            $stmt = $conn->prepare("SELECT 
                COALESCE(h.cours, 0) AS cours,
                COALESCE(h.td, 0) AS td,
                COALESCE(h.tp, 0) AS tp  
                FROM ue_h h 
                WHERE h.ue_id = ?");
            $stmt->execute([$id_ue]);
            $ue = $stmt->fetch();

            if ($ue) {
                $volume = 0;
                if ($cours) $volume += $ue['cours'];
                if ($td)    $volume += $ue['td'];
                if ($tp)    $volume += $ue['tp'];

                $charge_totale += $volume;

                $ordre_ue = isset($ordre_preferences[$id_ue]) ? (int)$ordre_preferences[$id_ue] : $ordre;
                $id_filiere = $_POST['filiere_id'][$id_ue] ?? null;

                $stmt = $conn->prepare("SELECT COUNT(*)  FROM choix_professeurs 
                    WHERE id_utilisateur = ? AND id_ue = ? AND annee_universitaire = ? ");
                $stmt->execute([$id_utilisateur, $id_ue, $annee_universitaire]);
                $exists = $stmt->fetchColumn();

                if (!$exists) {
                    $stmt = $conn->prepare("INSERT INTO choix_professeurs 
                        (id_utilisateur, id_ue, filiere_id, ordre_preference, annee_universitaire, cours, td, tp)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$id_utilisateur, $id_ue, $id_filiere, $ordre_ue, $annee_universitaire, $cours, $td, $tp]);

                }

                $ordre++;
            }
        }



        $_SESSION['charge_totale'] = $charge_totale;
        $_SESSION['message'] = "✅ Choix envoyés avec succès.";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = "❌ Aucune unité sélectionnée.";
        $_SESSION['message_type'] = 'error';
    }


}
$modules_choisis = [];
$modules_affectes = [];

if (isset($_SESSION['user_id'])) {
    $id_utilisateur = $_SESSION['user_id'];

    // Modules choisis par le prof
    $stmt1 = $conn->prepare("
    SELECT ue.nom AS nom_ue, f.nom_filiere AS nom_filiere, c.statut, c.cours, c.td, c.tp
    FROM choix_professeurs c
    JOIN utilisateurs u ON u.id_utilisateur = c.id_utilisateur
    JOIN unites_enseignement ue ON c.id_ue = ue.id_ue
    JOIN filieres f ON c.filiere_id = f.id_filiere
    WHERE c.id_utilisateur = ? AND u.departement_id = ?
   ");


    $stmt1->execute([$id_utilisateur ,  $departement_id]);
    $modules_choisis = $stmt1->fetchAll();

    // Modules affectés par le chef
    $stmt2 = $conn->prepare("
    SELECT ue.nom AS nom_ue, f.nom_filiere AS nom_filiere, a.annee_universitaire, a.cours, a.td, a.tp
    FROM affectations a
    JOIN unites_enseignement ue ON a.id_ue = ue.id_ue
    JOIN filieres f ON a.id_filiere = f.id_filiere
    WHERE a.id_utilisateur = ? AND  a.id_chef = ?
    ");


    $stmt2->execute([$id_utilisateur , $departement_id]);
    $modules_affectes = $stmt2->fetchAll();
}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }





/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
    transition: margin-left 0.3s ease;
}


        /*=========================================================*/

body {
    background: linear-gradient(135deg, #e9f8ef 0%, #b6f0c2 100%);
    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
    min-height: 100vh;
}

.container {
    max-width: 1100px;
    margin: 42px auto;
    background: #fff;
    border-radius: 18px;
    padding: 38px 32px 28px 32px;
    box-shadow: 0 8px 32px rgba(39, 174, 96, 0.11), 0 2px 8px rgba(0,0,0,0.05);
    position: relative;
}

h1 {
    text-align: center;
    color: #219150;
    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
    font-size: 2.3rem;
    font-weight: 700;
    margin-bottom: 24px;
    letter-spacing: 1px;
}

table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 15px;
    overflow: hidden;
    background: transparent;
    margin-bottom: 20px;
}

th, td {
    padding: 16px 10px;
    text-align: center;
    font-size: 1rem;
    border: none;
    transition: background 0.2s;
}

th {
    background: linear-gradient(90deg, #27ae60 0%, #219150 100%);
    color: white;
    font-size: 1.07rem;
    letter-spacing: 0.5px;
    font-weight: 600;
}

td {
    background: #f7fff9;
    color: #333;
}

tbody tr {
    border-bottom: 2px solid #e3e3e3;
    transition: background 0.2s;
}

tbody tr:hover {
    background: #eafbe7;
    box-shadow: 0 2px 8px rgba(39, 174, 96, 0.07);
    cursor: pointer;
}

.total {
    margin-top: 22px;
    font-weight: bold;
    font-size: 1.19rem;
    text-align: right;
    color: #27ae60;
    letter-spacing: 0.7px;
}

button, .ici {
    padding: 12px 26px;
    background: linear-gradient(90deg, #27ae60 70%, #219150 100%);
    color: #fff;
    border: none;
    border-radius: 30px;
    margin-top: 20px;
    font-size: 1.08rem;
    font-weight: 500;
    box-shadow: 0 2px 8px rgba(39, 174, 96, 0.10);
    cursor: pointer;
    transition: background 0.25s, box-shadow 0.2s, transform 0.17s;
}

button:hover, .ici:hover {
    background: linear-gradient(90deg, #219150 0%, #27ae60 100%);
    box-shadow: 0 4px 16px rgba(39, 174, 96, 0.15);
    transform: scale(1.04);
}

.ici {
    background: linear-gradient(90deg, #222 70%, #444 100%);
    color: white;
}

.ici:hover {
    background: linear-gradient(90deg, #666 0%, #222 100%);
}

.alert {
    text-align: center;
    font-size: 1.15rem;
    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
    border-radius: 8px;
    margin: 18px auto;
    padding: 14px 18px;
    max-width: 600px;
    box-shadow: 0 2px 8px rgba(39,174,96,0.07);
}

.alert.success {
    background: #e9f8ef;
    color: #27ae60;
    font-weight: bold;
    border: 1.5px solid #27ae60;
}
.alert.warning {
    background: #fff8e1;
    color: #e67e22;
    font-weight: bold;
    border: 1.5px solid #e67e22;
}
.alert.error {
    background: #fff3f3;
    color: #c0392b;
    font-weight: bold;
    border: 1.5px solid #c0392b;
}

/* Responsive */
@media (max-width: 900px) {
    .container {
        padding: 18px 4px;
    }
    th, td {
        padding: 10px 4px;
        font-size: 15px;
    }
}

@media (max-width: 650px) {
    table, thead, tbody, th, td, tr {
        display: block;
        width: 100%;
    }
    thead tr {
        display: none;
    }
    tbody tr {
        margin-bottom: 14px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(39,174,96,0.05);
    }
    td {
        position: relative;
        padding-left: 110px;
        border: none;
        border-bottom: 1px solid #eaeaea;
    }
    td[data-label]::before {
        content: attr(data-label);
        display: inline-block;
        position: absolute;
        left: 16px;
        top: 16px;
        font-size: 0.98rem;
        color: #27ae60;
        font-weight: bold;
    }
}

::-webkit-scrollbar {
    width: 7px;
    background: #e9f8ef;
    border-radius: 8px;
}
::-webkit-scrollbar-thumb {
    background: #27ae60;
    border-radius: 8px;
}

.top-right-icon {
    position: absolute;
    top: 20px;
    right: 30px;
}

.top-right-icon img {
    width: 40px;
    height: 40px;
    cursor: pointer;
    transition: transform 0.3s;
}

.top-right-icon img:hover {
    transform: scale(1.2);
}

.ue-scroll {
    max-height: 620px;       /* Hauteur visible, avec scroll si dépasse */
    overflow-y: auto;
    border: 1.5px solid #27ae60;
    border-radius: 15px;
    background: linear-gradient(90deg, #f7fff9 60%, #e6fbe7 100%);
    box-shadow: 0 2px 8px rgba(39, 174, 96, 0.07);
    margin-bottom: 20px;
}

/* Scrollbar personnalisée */
.ue-scroll::-webkit-scrollbar {
    width: 9px;
    background: #e9f8ef;
    border-radius: 8px;
}
.ue-scroll::-webkit-scrollbar-thumb {
    background: #27ae60;
    border-radius: 8px;
}
.ue-scroll::-webkit-scrollbar-thumb:hover {
    background: #219150;
}

/* Table style */
.ue-scroll table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 12px;
    overflow: hidden;
    background: transparent;
}
.ue-scroll th, .ue-scroll td {
    padding: 13px 8px;
    text-align: center;
    font-size: 0.98rem;
    border: none;
    transition: background 0.2s;
}
.ue-scroll th {
    background: linear-gradient(90deg, #27ae60 0%, #219150 100%);
    color: white;
    font-weight: 600;
    font-size: 1.03rem;
}
.ue-scroll td {
    background: #f7fff9;
    color: #333;
}
.ue-scroll tbody tr:hover {
    background: #eafbe7;
    box-shadow: 0 2px 8px rgba(39, 174, 96, 0.07);
    cursor: pointer;
}

</style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
        <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" ry="2"/>
        <path d="M8 2v4"/>
      </svg>
      <a href="./ue.php">Unités d'enseignement</a>
    </li>

    <li>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M9 11l3 3L22 4"/>
    <path d="M2 5h6"/>
    <path d="M2 10h6"/>
    <path d="M2 15h6"/>
  </svg>
  <a href="./souhait.php" class="a_items">Souhaite</a>
</li>

    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="historique.php">Historique</a>
    </li>

    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
     
     
    <div class="main-content">
        <?php if (!$choix_actif): ?>
    <div class="alert alert-warning text-center mt-4">
        ❌ La fonctionnalité des souhaits est actuellement <strong>désactivée</strong> par le chef de département.
    </div>
<?php else: ?>
    <?php if ($date_limite): ?>
        <div class="alert alert-info text-end me-4 mt-2">
            📅 Vous pouvez faire vos souhaits jusqu’au : <strong><?= $date_limite ?></strong>
        </div>
    <?php endif; ?>
<?php endif; ?>

   <?php if ($choix_actif): ?>
    <!-- TON TABLEAU HTML ICI -->
 
    <br><br><div class="container">
    <?php if (isset($_SESSION['message'])): ?>
    <div class="alert <?= $_SESSION['message_type'] ?>">
        <?= $_SESSION['message'] ?>
    </div>
    <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
    <?php endif; ?>
    <h1>Choix des Unités d'Enseignement</h1>
    <form method="post" action = "" >
        <div class="ue-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Sélection</th>
                        <th>Nom UE</th>
                        <th>Filiere</th>
                        <th>Cours (h)</th>
                        <th>TD (h)</th>
                        <th>TP (h)</th>
                        <th>Ordre de Préférence</th>
                        <th>Cours </th>
                        <th>TD </th>
                        <th>TP </th>
                    </tr>
                </thead>
                <tbody>
                  <?php
                    // Récupération des filières
                    $filieres = $conn->query("SELECT id_filiere, nom_filiere FROM filieres")->fetchAll(PDO::FETCH_ASSOC);

                    $stmt_ue = $conn->prepare("SELECT ue.*, 
                        COALESCE(h.cours, 0) AS cours,
                        COALESCE(h.td, 0) AS td,
                        COALESCE(h.tp, 0) AS tp 
                        FROM unites_enseignement ue
                        LEFT JOIN ue_h h ON ue.id_ue = h.ue_id  
                        WHERE departement_id = ?");
                    $stmt_ue->execute([$departement_id]);

                    while ($ue = $stmt_ue->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='ue_ids[]' value='{$ue['id_ue']}'></td>";
                        echo "<td>" . htmlspecialchars($ue['nom']) . "</td>";

                        // FILIERE SELECT
                        echo "<td>";
                        echo "<select name='filiere_id[{$ue['id_ue']}]' >";
                        echo "<option value=''>-- Choisir --</option>";
                        foreach ($filieres as $filiere) {
                            echo "<option value='{$filiere['id_filiere']}'>" . htmlspecialchars($filiere['nom_filiere']) . "</option>";
                        }
                        echo "</select>";
                        echo "</td>";

                        // Volume horaire
                        echo "<td>" . htmlspecialchars($ue['cours']) . " h</td>";
                        echo "<td>" . htmlspecialchars($ue['td']) . " h</td>";
                        echo "<td>" . htmlspecialchars($ue['tp']) . " h</td>";

                        // Ordre de préférence
                        echo "<td><input type='number' name='ordre_preference[{$ue['id_ue']}]' min='1' max='10'></td>";

                        // Type d'affectation
                        echo "<td><input type='checkbox' class='volume' data-volume='{$ue['cours']}' onchange='updateTotal()' name='type_affectation[{$ue['id_ue']}][cours]' value='1'></td>";
                        echo "<td><input type='checkbox' class='volume' data-volume='{$ue['td']}' onchange='updateTotal()' name='type_affectation[{$ue['id_ue']}][td]' value='1'></td>";
                        echo "<td><input type='checkbox' class='volume' data-volume='{$ue['tp']}' onchange='updateTotal()' name='type_affectation[{$ue['id_ue']}][tp]' value='1'></td>";

                        echo "</tr>";
                    }
                    ?>
                    </tbody>

            </table>
        </div>
        <div class="total" id="totalVolume">Charge horaire totale : 0h</div>
        <button class = "ici" type="button" onclick="uncheckAll()">Tout décocher</button>
        <button type="submit">Valider les choix</button>
        
    </form>
                <!--==========================================================0-->
       <br><br> <?php if (!empty($modules_choisis)): ?>
        <div class="card shadow-sm mt-4">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-check-circle-fill"></i> Modules choisis par le professeur
            </div><br>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        
                         <tr>
                            <th>Module</th>
                            <th>Filière</th>
                            <th>Type d'affectation</th>
                            <th>État</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($modules_choisis as $m): ?>
                            <tr>
                                <td><?= htmlspecialchars($m['nom_ue']) ?></td>
                                <td><?= htmlspecialchars($m['nom_filiere']) ?></td>
                                <td>
                                    <?php
                                    $types = [];
                                    if ($m['cours']) $types[] = 'Cours';
                                    if ($m['td']) $types[] = 'TD';
                                    if ($m['tp']) $types[] = 'TP';
                                    echo implode(' + ', $types);
                                    ?>
                                </td>

                                <td>
                                    <?php if ($m['statut'] == 'valide'): ?>
                                        <span class="badge bg-success" style = "color:green">✅ Validé</span>
                                    <?php elseif ($m['statut'] == 'refuse'): ?>
                                        <span class="badge bg-danger" style = "color:red">❌ Refusé</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark" >En attente</span>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

   <br><br> <?php if (!empty($modules_affectes)): ?>
        <div class="card shadow-sm mt-4">
            <div class="card-header bg-success text-white">
                <i class="bi bi-person-badge-fill"></i> Modules affectés par le chef de département
            </div><br>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Module</th>
                            <th>Filière</th>
                            <th>Type d'affectation</th>
                            <th>Année universitaire</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($modules_affectes as $m): ?>
                            <tr>
                                <td><?= htmlspecialchars($m['nom_ue']) ?></td>
                                <td><?= htmlspecialchars($m['nom_filiere']) ?></td>
                                <td>
                                    <?php
                                    $types = [];
                                    if ($m['cours']) $types[] = 'Cours';
                                    if ($m['td']) $types[] = 'TD';
                                    if ($m['tp']) $types[] = 'TP';
                                    echo implode(' + ', $types);
                                    ?>
                                </td>
                                <td><?= $m['annee_universitaire'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    <?php endif; ?>

</div>

        <script>
            function updateTotal() {
                const checkboxes = document.querySelectorAll("input.volume");
                let total = 0;

                checkboxes.forEach(cb => {
                    if (cb.checked) {
                        total += parseInt(cb.getAttribute('data-volume')) || 0;
                    }
                });

                const totalEl = document.getElementById('totalVolume');
                totalEl.textContent = "Charge horaire totale : " + total + "h";

                if (total < 120) {
                    totalEl.style.color = 'red';
                    totalEl.textContent += " ⚠️ (Charge minimale non atteinte)";
                } else {
                    totalEl.style.color = 'green';
                }
            }

            function uncheckAll() {
                document.querySelectorAll("input[type='checkbox']").forEach(cb => cb.checked = false);
                updateTotal();
            }
        </script>




    </div>
    <script>
    
               function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>

</body>
</html>
    
