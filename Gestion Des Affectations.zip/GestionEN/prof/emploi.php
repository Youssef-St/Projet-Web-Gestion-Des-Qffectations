<?php
session_start();
require_once '../config/db.php';



$prof_id = $_SESSION['user_id'];

$sql = "SELECT ep.jour_semaine, ep.heure_debut, ep.heure_fin, ue.nom AS ue, ep.salle, f.nom_filiere, ep.semestre
        FROM emplois_profs ep
        JOIN unites_enseignement ue ON ep.id_ue = ue.id_ue
        JOIN filieres f ON ep.id_filiere = f.id_filiere
        WHERE ep.id_utilisateur = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$prof_id]);
$emplois = $stmt->fetchAll();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
            background-color: #f5f5f5;
        }
        
        /* Barre latérale gauche */
        .sidebar {
            width: 250px;
            background-color:rgb(83, 190, 34);
            color: white;
            padding: 20px 0;
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
        }
        
        .logo-container {
            text-align: center;
            padding: 20px;
        }
          .logo-container h2{
            font-family: "Poppins", sans-serif;
            color : rgb(63, 71, 56);
          }
        .logo a {
            width: 120px;
            height: 120px;
            scale : 1.2;
            margin: -25px auto;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            font-size: 24px;
        }
        
        .nav-menu {
            flex-grow: 1;
        }
        
        .nav-item {
            transition: background-color 0.3s;
        }
        
        .barre {
            border-bottom: 1px solid rgb(154, 212, 127);
            width: 80%; /* Largeur */
            margin: 10px 17px; /* Espacement vertical */
            
        }
                    
        
        .nav-item.active {
            background-color:rgb(83, 190, 34);
            padding : 20px;
            margin-bottom: 40px;
            
        }
        .a_items{
   
         text-decoration : none;
         color : rgb(154, 212, 127);
         
         
        }
        ul > li{
            list-style: none ;
            padding : 15px 10px ;
        }
        .a_items:hover{
            color: rgb(233, 240, 229) ;
        }
        
        /* Contenu principal */
        .main-content {
            flex-grow: 1;
            margin-left: 250px;
            padding: 20px;
            background-color: white;
            min-height: 100vh;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        .top-right-icon {
            position: absolute;
            top: 20px;
            right: 30px;
            }

        .top-right-icon img {
            width: 40px;
            height: 40px;
            cursor: pointer;
            transition: transform 0.3s;
            }

        .top-right-icon img:hover {
            transform: scale(1.2);

        }

        /*===============================================*/

        /* STYLE POUR LE TABLEAU D’EMPLOI DU TEMPS */
        .emploi-container {
            max-width: 1000px;
            margin: 40px auto;
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .emploi-container h2 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 28px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-family: 'Segoe UI', sans-serif;
            font-size: 16px;
        }

        th, td {
            padding: 14px 18px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
            font-size: 17px;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #eaf2ff;
        }

        td {
            color: #333;
        }


        </style>
</head>
<body>
   
    <div class="sidebar">
        <div class="logo-container">
            <div class="logo"><a href="./accueil.php"><img src="../images/logo1.png" alt="logo"></a></div>
            <h2>e-Services</h2>
        </div>
        <div class="barre"></div>
        <div class="nav-menu">
            <div class="nav-item active">
              <ul >
                <li><a href="./accueil.php" class = "a_items">Accueil</a></li>
                <li><a href="./UE.php" class = "a_items">Unités d'enseignement</a></li>
                <li><a href="./souhait.php" class = "a_items">Souhaite</a></li>
                <li><a href="./notes.php" class = "a_items">Notes</a></li>
                 <li><a href="./emploi.php" class = "a_items">Emploi du Temps</a></li>
                <li><a href="historique.php" class = "a_items">Historique</a></li>
                <li><a href="../login.php" class = "a_items">Déconnexion</a></li>

              </ul>
            </div>
        </div>
    </div>
    
     
    <div class="main-content">
<div class="emploi-container">
    <h2>Mon emploi du temps</h2>

    <?php if (!empty($emplois)) : ?>
        <table>
            <tr>
                <th>Jour</th>
                <th>Heure début</th>
                <th>Heure fin</th>
                <th>UE</th>
                <th>Salle</th>
                <th>Filière</th>
                <th>Semestre</th>
            </tr>
            <?php foreach ($emplois as $emploi) : ?>
                <tr>
                    <td><?= htmlspecialchars($emploi['jour_semaine']) ?></td>
                    <td><?= htmlspecialchars($emploi['heure_debut']) ?></td>
                    <td><?= htmlspecialchars($emploi['heure_fin']) ?></td>
                    <td><?= htmlspecialchars($emploi['ue']) ?></td>
                    <td><?= htmlspecialchars($emploi['salle']) ?></td>
                    <td><?= htmlspecialchars($emploi['nom_filiere']) ?></td>
                    <td><?= htmlspecialchars($emploi['semestre']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else : ?>
        <p style="text-align:center;">Aucun emploi du temps trouvé pour vous.</p>
    <?php endif; ?>
</div>


    </div>
</body>
</html>
    
