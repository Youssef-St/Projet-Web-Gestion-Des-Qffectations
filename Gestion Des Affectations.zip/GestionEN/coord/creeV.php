<?php
// Import PHPMailer classes en haut du fichier
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

// Traitement création compte
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'ajouter') {
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $email = trim($_POST['email']);
    $specialite = trim($_POST['specialite']);
    $mot_de_passe_clair = $_POST['mot_de_passe'];
    $mot_de_passe_temp = password_hash($mot_de_passe_clair, PASSWORD_DEFAULT);
    $departement_id = $_POST['departement_id'];

    try {
        // Insertion dans la base de données
        $stmt = $conn->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, specialite, departement_id, role_id, created_by)
                                VALUES (?, ?, ?, ?, ?, ?, 5, ?)");
        $stmt->execute([$nom, $prenom, $email, $mot_de_passe_temp, $specialite, $departement_id, $_SESSION['user_id']]);


        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ystitou18@gmail.com';
        $mail->Password   = 'xozo zrzn bzhh rixw'; // mot de passe d'application Gmail
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        $mail->setFrom('ystitou18@gmail.com', 'Administration');
        $mail->addAddress($email, $prenom . ' ' . $nom); // <- ici $email est bien défini

        $mail->isHTML(true);
        $mail->Subject = 'Création de votre compte vacataire';
        $mail->Body = "
            <p>Bonjour cher professeur,</p>
            <p>Votre compte vacataire a été créé avec succès.</p>
            <p>Mot de passe temporaire : <b>$mot_de_passe_clair</b></p>
            <p>Merci de le modifier dès la première connexion.</p>
            <p>Cordialement,<br>Administration</p>
        ";
        $mail->AltBody = "Bonjour, votre compte vacataire a été créé. Mot de passe : $mot_de_passe_clair";

        $mail->send();

        $message = "✅ Compte créé et email envoyé avec succès.";
    } catch (Exception $e) {
        $message = "❌ Erreur lors de l'envoi de l'email : {$mail->ErrorInfo}";
    } catch (PDOException $e) {
        $message = "❌ Erreur base de données : " . $e->getMessage();
    }
}


// Traitement modification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'modifier') {
    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mot_de_passe = !empty($_POST['mot_de_passe']) ? password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT) : null;

    if ($mot_de_passe) {
        $stmt = $conn->prepare("UPDATE utilisateurs SET nom=?, prenom=?, email=?, mot_de_passe=? WHERE id_utilisateur=?");
        $stmt->execute([$nom, $prenom, $email, $mot_de_passe, $id]);
    } else {
        $stmt = $conn->prepare("UPDATE utilisateurs SET nom=?, prenom=?, email=? WHERE id_utilisateur=?");
        $stmt->execute([$nom, $prenom, $email, $id]);
    }
    $message = "✏️ Compte mis à jour.";
}
// Traitement supprimer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'supprimer') {
    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM utilisateurs WHERE id_utilisateur=?");
    $stmt->execute([$id]);
    
    $message = "🗑️ Compte supprimé avec succès.";
}
// recuperer les vacataire de departement 
$stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE role_id = 5 AND created_by = ?");
$stmt->execute([$_SESSION['user_id']]);
$vacataires = $stmt->fetchAll();

?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
    <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}



/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}
   


    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }


        /*=========================================*/

/* Contenu principal */
.main-content {
    flex-grow: 1;
    margin-left: 250px;
    padding: 40px;
    background-color: #f4f6f9;
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    transition: margin-left 0.3s ease;
}

h2.ic {
    color: #2d2d2d;
    border-left: 6px solid #3da35d;
    padding-left: 15px;
    font-size: 24px;
    margin-bottom: 20px;
}

/* Formulaire */
.form-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 20px;
    padding: 30px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    margin-bottom: 40px;
}

.form-container input,
.form-container select {
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 10px;
    font-size: 16px;
    background-color: #fefefe;
    transition: border-color 0.3s;
}

.form-container input:focus,
.form-container select:focus {
    border-color: #3da35d;
    outline: none;
}

.btn {
    grid-column: span 2;
    padding: 12px;
    background-color: #3da35d;
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #2b7a45;
}

.btn1 {
    background-color: transparent;
    border: none;
    cursor: pointer;
}

.success {
    color: green;
    font-weight: bold;
}

.error {
    color: red;
    font-weight: bold;
}

/* Tableau */
.styled-table {
    width: 100%;
    border-collapse: collapse;
    background-color: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 3px 10px rgba(0,0,0,0.07);
}

.styled-table th, .styled-table td {
    padding: 16px;
    border: 1px solid #e0e0e0;
    text-align: left;
}

.styled-table th {
    background-color: #3da35d;
    color: #fff;
    font-size: 16px;
    text-transform: uppercase;
}

.styled-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.styled-table td input[type="text"],
.styled-table td input[type="email"],
.styled-table td input[type="password"] {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 14px;
}



        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" ry="2"/>
        <path d="M8 2v4"/>
      </svg>
      <a href="./ue.php">Unités d'enseignement</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 6v6l4 2"/>
      </svg>
      <a href="./Lafect.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="7" width="16" height="10" rx="2"/>
        <path d="M16 3v4"/>
      </svg>
      <a href="./creeV.php">Compte Vacataire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 9l6 6 6-6"/>
      </svg>
      <a href="./ue_vac.php">Affectation UE / Vac</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h16"/>
        <path d="M12 2v16"/>
      </svg>
      <a href="./notes.php">Notes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <path d="M9 9h6v6H9z"/>
      </svg>
      <a href="./historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./prof/souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./prof/notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./prof/historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>

    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M16 17l-4-4-4 4"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>



    <div class="main-content">
    <h2 class = "ic">Ajouter un vacataire</h2><br>

<?php if (!empty($message)): ?>
    <p class="<?= strpos($message, '❌') !== false ? 'error' : 'success' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" class="form-container" >
    <input type="hidden" name="action" value="ajouter">
    <input type="text" name="nom" placeholder="Nom" required>
    <input type="text" name="prenom" placeholder="Prénom" required>
    <input type="email" name="email" placeholder="Email" required>
    
    <select name="departement_id" required>
        <option value="">-- Choisir département --</option>
        <?php
        $stmt = $conn->query("SELECT id_departement, nomD FROM departements");
        while ($d = $stmt->fetch()) {
            echo "<option value='{$d['id_departement']}'>{$d['nomD']}</option>";
        }
        ?>
    </select>


    <input type="text" name="specialite" placeholder="Spécialité" required>
    <input type="text" name="mot_de_passe" placeholder="Mot de passe temporaire" required>
    <button type="submit" class="btn">Créer le compte</button>
</form>

<h2 class ="ic">Liste des vacataires</h2><br>

<table class="styled-table">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Mot de passe</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($vacataires as $v): ?>
        <tr>
            <form method="POST" style="display: contents;">
                <input type="hidden" name="action" value="modifier">
                <input type="hidden" name="id" value="<?= $v['id_utilisateur'] ?>">
                
                <td><input type="text" name="nom" value="<?= htmlspecialchars($v['nom']) ?>"></td>
                <td><input type="text" name="prenom" value="<?= htmlspecialchars($v['prenom']) ?>"></td>
                <td><input type="email" name="email" value="<?= htmlspecialchars($v['email']) ?>"></td>
                <td><input type="password" name="mot_de_passe" placeholder="Nouveau mot de passe"></td>
                <td style="white-space: nowrap;">
                    <!-- Modifier -->
                    <button type="submit" class="btn1">
                        <img src="img/modifier.png" alt="modifier">
                    </button>
            </form>

            <!-- Supprimer (form séparé mais dans la même cellule) -->
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="supprimer">
                <input type="hidden" name="id" value="<?= $v['id_utilisateur'] ?>">
                <button type="submit" class="btn1">
                    <img src="img/supp.png" alt="Supprimer">
                </button>
            </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>



    </div>
    <script>
             function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
  <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
    
