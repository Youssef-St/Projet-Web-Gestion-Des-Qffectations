<?php
session_start();

require_once '../config/db.php'; // adapte le chemin si besoin

$id_utilisateurc = $_SESSION['user_id'];

$stmt = $conn->query("SELECT id FROM fichiers");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stmtCheck = $conn->prepare("SELECT 1 FROM fichiers_vus WHERE id_utilisateur = ? AND id_fichier = ?");
    $stmtCheck->execute([$id_utilisateurc, $row['id']]);
    if (!$stmtCheck->fetch()) {
        $stmtInsert = $conn->prepare("INSERT INTO fichiers_vus (id_utilisateur, id_fichier) VALUES (?, ?)");
        $stmtInsert->execute([$id_utilisateurc, $row['id']]);
    }
}


// Crée le dossier uploads/ s'il n'existe pas
if (!is_dir('../uploads')) {
    mkdir('../uploads', 0777, true);
}

// Traitement de l'upload
if (isset($_POST['upload'])) {
    $fileName = basename($_FILES['excel_file']['name']);
    $fileTmpName = $_FILES['excel_file']['tmp_name'];

    // Destination finale
    $destination = __DIR__ . '/../uploads/' . $fileName;

    if (move_uploaded_file($fileTmpName, $destination)) {
        $nomUtilisateur = $_SESSION['nom_utilisateurc'] ?? 'Inconnu';
        $stmt = $conn->prepare("INSERT INTO fichiers (nom_fichier, date_upload, nom_utilisateur, vu) VALUES (?, NOW(), ?, 0)");
        $stmt->execute([$fileName, $nomUtilisateur]);
        
        
    } else {
        $_SESSION['error'] = 'Erreur lors de l\'upload du fichier.';
    }
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

// Traitement du téléchargement
if (isset($_GET['download'])) {
    $fileName = basename($_GET['download']);
    $filePath = __DIR__ . '/../uploads/' . $fileName;

    if (file_exists($filePath) && is_file($filePath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    } else {
        header("HTTP/1.0 404 Not Found");
        die("Fichier non trouvé: " . htmlspecialchars($fileName));
    }
}
if (isset($_GET['delete'])) {
    $fileName = basename($_GET['delete']);

    // Vérifie que l'utilisateur est bien l'auteur du fichier
    $stmt = $conn->prepare("SELECT * FROM fichiers WHERE nom_fichier = ?");
    $stmt->execute([$fileName]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($file && $file['nom_utilisateur'] === $_SESSION['nom_utilisateurc']) {
        $filePath = __DIR__ . '/../uploads/' . $fileName;
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Supprimer de la base de données
        $stmt = $conn->prepare("DELETE FROM fichiers WHERE nom_fichier = ?");
        $stmt->execute([$fileName]);
    }

    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <title>Plateforme e-Services</title>
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', 'Arial', sans-serif;
}

body {
    display: flex;
    min-height: 100vh;
    background-color: #f0f2f5;
}

/* ===== SIDEBAR ===== */
.sidebar {
    width: 260px;
    background: linear-gradient(180deg,rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
    color: white;
    padding: 25px 0;
    height: 100vh;
    position: fixed;
    display: flex;
    flex-direction: column;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.logo-container {
    text-align: center;
    padding:  20px ;
}

.logo-container h2 {
    font-family: 'Poppins', sans-serif;
    font-size: 24px;
    color: rgb(63, 71, 56);
}

.logo a img {
    width: 100%;
    height: 120px;
    border-radius: 50%;
    margin: -25px auto;
    transition: transform 0.3s ease;
}

.logo a img:hover {
    transform: scale(1.05);
}

.barre {
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    width: 80%;
    margin: 15px auto;
}

.nav-menu {
    flex-grow: 1;
}

ul {
    list-style: none;
    padding-left: 0;
}

.nav-item ul li {
    padding: 12px 25px;
    transition: all 0.2s ease-in-out;
    border-left: 4px solid transparent;
}

.nav-item ul li:hover {
    background-color: rgba(255, 255, 255, 0.1);
    border-left: 4px solid #C8E6C9;
}

.nav-item ul li a {
    text-decoration: none;
    color: #e0f2f1;
    font-size: 16px;
    display: block;
    transition: color 0.3s;
}

.nav-item ul li a:hover {
    color: #ffffff;
}

.nav-item ul li.active {
    background-color: rgba(255, 255, 255, 0.15);
    border-left: 4px solid #ffffff;
}



/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 260px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}

        /*=======================================================*/

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        h1, h2 {
            text-align: center;
            color: #2c3e50;
        }
        form {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        input[type="file"] {
            padding: 8px;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }



                /* Responsive */
                @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        a.icon-btn {
            font-size: 20px;
            text-decoration: none;
            margin: 0 6px;
            padding: 6px 10px;
            border-radius: 6px;
            display: inline-block;
            transition: background 0.3s;
        }

        a.icon-btn.download {
            color: white;
        }


        a.icon-btn.delete {
            color: white;
        }


                        ul .collapse {
            background-color: #f8f9fa; /* plus doux que blanc pur */
            border-radius: 8px;
            padding: 8px 0;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
            margin-top: 4px;
            transition: all 0.3s ease;
        }

        ul .collapse li {
            padding: 4px 16px;
        }

        ul .collapse li a {
            display: block;
            color: #343a40;
            text-decoration: none;
            padding: 6px 10px;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        ul .collapse li a:hover {
            background-color: #e2e6ea;
            color: #000;
        }

    </style>
</head>
<body>
   
<div class="sidebar">
        <div class="logo-container">
            <div class="logo"><a href="./accueil.php"><img src="../images/logo1.png" alt="logo"></a></div>
            <h2>e-Services</h2>
        </div>
        <div class="barre"></div>
        <div class="nav-menu">
            <div class="nav-item active">
              <ul >
                <li><a href="./accueil.php" class = "a_items">Accueil</a></li>
                <li><a href="./ue.php" class = "a_items">Unités d'enseignement</a></li>
                <li><a href="./Lafect.php" class = "a_items">Affectation</a></li>
                <li><a href="./creeV.php" class = "a_items">Compte Vacataire</a></li>
                <li><a href="./ue_vac.php" class = "a_items">Affectation UE / Vac</a></li>
                <li><a href="./notes.php" class = "a_items">Notes</a></li>
                <li><a href="./historique.php" class = "a_items">Historique</a></li>
                <li>
                    <a class="a_items dropdown-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
                        Fonctions Professeur
                    </a>
                    <ul id="profMenu" class="collapse list-unstyled ms-3">
                        <li><a href="./prof/souhait.php" class="a_items">Souhait</a></li>
                        <li><a href="./prof/notes.php" class="a_items">Notes</a></li>
                        <li><a href="./prof/historiquepf.php" class="a_items">Historique</a></li>
                    </ul>
                </li>
                
                <li><a href="../login.php" class = "a_items">Déconnexion</a></li>

              </ul>
            </div>
        </div>
    </div>
    
     
    <div class="main-content">


    <div class="container">
    <h1>📄 Partage de Fichiers Excel</h1>

    <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

    <form method="post" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xlsx" required>
        <button type="submit" name="upload">Envoyer</button>
        
    </form>

    <h2>Fichiers partagés 📚</h2>
    <table>
    <tr>
            <th>Nom du fichier</th>
            <th>Date d'upload</th>
            <th>Envoyé par</th>
            <th>Action</th>
        </tr>
        <?php
            $stmt = $conn->query("SELECT * FROM fichiers ORDER BY date_upload DESC");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['nom_fichier']) . "</td>";
                echo "<td>" . $row['date_upload'] . "</td>";
                echo "<td>" . htmlspecialchars($row['nom_utilisateur']) . "</td>";
                echo "<td>";
                echo "<a class='icon-btn download' href='?download=" . urlencode($row['nom_fichier']) . "' title='Télécharger'><img src='img/tele.png' alt='📥'></a>";
                if ($_SESSION['nom_utilisateurc'] === $row['nom_utilisateur']) {
                    echo "<a class='icon-btn delete' href='?delete=" . urlencode($row['nom_fichier']) . "' title='Supprimer' onclick=\"return confirm('Supprimer ce fichier ?')\"><img src='img/supp.png' alt='🗑️'></a>";
                }
                echo "</td>";
                echo "</tr>";
            }
        ?>
    </table>
</div>
    </div>
    <script>
    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
</body>
</html>
    
