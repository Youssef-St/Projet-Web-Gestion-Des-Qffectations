<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

$id_utilisateurc = $_SESSION['user_id'];

$mois = date('n'); // Numéro du mois (1 à 12)
$annee = date('Y');
$annee_universitaire = ($mois >= 8) ? "$annee-" . ($annee + 1) : ($annee - 1) . "-$annee";

$req = $conn->prepare("
    SELECT n.id_note, u.nom, u.prenom, ue.nom AS ue_nom, n.type_session,
           n.fichier, n.annee_universitaire, n.date_upload, f.nom_filiere
    FROM notes n
    JOIN utilisateurs u ON u.id_utilisateur = n.id_utilisateur
    JOIN unites_enseignement ue ON ue.id_ue = n.id_ue
    JOIN filieres f ON f.id_filiere = n.filiere_id
    WHERE n.annee_universitaire = ? AND n.filiere_id = ?
    ORDER BY n.date_upload DESC
");
$req->execute([$annee_universitaire , $_SESSION['id_filiere']]);
$notes = $req->fetchAll(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
     <script src="https://cdn.tailwindcss.com"></script>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

        <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
    <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}



/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}
   

/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
    transition: margin-left 0.3s ease;
}
.sidebar.collapsed ~ .main-content{
  margin-left: 60px;
}


        /*=======================================================================*/
                                           /*profile*/


        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" ry="2"/>
        <path d="M8 2v4"/>
      </svg>
      <a href="./ue.php">Unités d'enseignement</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 6v6l4 2"/>
      </svg>
      <a href="./Lafect.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="7" width="16" height="10" rx="2"/>
        <path d="M16 3v4"/>
      </svg>
      <a href="./creeV.php">Compte Vacataire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 9l6 6 6-6"/>
      </svg>
      <a href="./ue_vac.php">Affectation UE / Vac</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h16"/>
        <path d="M12 2v16"/>
      </svg>
      <a href="./notes.php">Notes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <path d="M9 9h6v6H9z"/>
      </svg>
      <a href="./historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
              stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="10" cy="10" r="8"/>
            <path d="M10 14v4"/>
            <path d="M10 6v4"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./prof/souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./prof/notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./prof/historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M16 17l-4-4-4 4"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
    <div class="main-content">
   
 <div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-semibold mb-8 text-gray-800">📁 Fichiers de notes uploadés</h1>

    <div class="overflow-x-auto bg-white shadow-xl rounded-xl">
        <table class="min-w-full divide-y divide-gray-300">
            <thead class="bg-blue-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Enseignant</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UE</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Filière</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Session</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Année</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Fichier</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($notes as $note): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 text-sm text-gray-700"><?= htmlspecialchars($note['nom'] . ' ' . $note['prenom']) ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= htmlspecialchars($note['ue_nom']) ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= htmlspecialchars($note['nom_filiere']) ?></td>
                        <td class="px-6 py-4 text-sm">
                            <span class="px-2 py-1 rounded-full text-xs font-medium 
                                <?= $note['type_session'] === 'Normale' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' ?>">
                                <?= htmlspecialchars($note['type_session']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?= htmlspecialchars($note['annee_universitaire']) ?></td>
                        <td class="px-6 py-4 text-sm text-gray-600">
                            <?= date('d/m/Y à H:i', strtotime($note['date_upload'])) ?>
                        </td>
                        <td class="px-6 py-4 text-sm">
                            
                                <a href="../uploads/notes/<?= htmlspecialchars($note['fichier']) ?>" 
                                   class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
                                   download>Telechatger

                                </a>
                    
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
  

    </div>
    <script>

             function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
  <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
    
