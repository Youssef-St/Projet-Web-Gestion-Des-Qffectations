<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin




?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Plateforme e-Services</title>
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', 'Arial', sans-serif;
}

body {
    display: flex;
    min-height: 100vh;
    background-color: #f0f2f5;
}

/* ===== SIDEBAR ===== */
.sidebar {
    width: 260px;
    background: linear-gradient(180deg,rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
    color: white;
    padding: 25px 0;
    height: 100vh;
    position: fixed;
    display: flex;
    flex-direction: column;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.logo-container {
    text-align: center;
    padding:  20px ;
}

.logo-container h2 {
    font-family: 'Poppins', sans-serif;
    font-size: 24px;
    color: rgb(63, 71, 56);
}

.logo a img {
    width: 100%;
    height: 120px;
    border-radius: 50%;
    margin: -25px auto;
    transition: transform 0.3s ease;
}

.logo a img:hover {
    transform: scale(1.05);
}

.barre {
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    width: 80%;
    margin: 15px auto;
}

.nav-menu {
    flex-grow: 1;
}

ul {
    list-style: none;
    padding-left: 0;
}

.nav-item ul li {
    padding: 12px 25px;
    transition: all 0.2s ease-in-out;
    border-left: 4px solid transparent;
}

.nav-item ul li:hover {
    background-color: rgba(255, 255, 255, 0.1);
    border-left: 4px solid #C8E6C9;
}

.nav-item ul li a {
    text-decoration: none;
    color: #e0f2f1;
    font-size: 16px;
    display: block;
    transition: color 0.3s;
}

.nav-item ul li a:hover {
    color: #ffffff;
}

.nav-item ul li.active {
    background-color: rgba(255, 255, 255, 0.15);
    border-left: 4px solid #ffffff;
}



/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 260px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}

/*==============================================*/

/* Style général des formulaires */
form {
    background-color: #ffffff;
    border-radius: 16px;
    padding: 30px;
    width: 95%;
    max-width: 900px;
    margin: 0 auto 40px auto;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    font-size: 1.1rem;
}

/* Champs de formulaire */
form select,
form input[type="text"],
form input[type="time"],
form button {
    padding: 14px;
    margin: 10px 0;
    width: 100%;
    font-size: 1rem;
    border-radius: 8px;
    border: 1px solid #ced4da;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

/* Focus sur les champs */
form select:focus,
form input[type="text"]:focus,
form input[type="time"]:focus {
    border-color: #3da35d;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.25);
    outline: none;
}

/* Bouton */
button {
    background-color: #3da35d;
    color: white;
    border: none;
    padding: 14px;
    font-weight: bold;
    font-size: 1rem;
    border-radius: 8px;
    cursor: pointer;
    margin-top: 15px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #155724;
}

/* Table style */
table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 40px;
    background-color: #ffffff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

/* Cellules */
th, td {
    border: 1px solid #dee2e6;
    padding: 18px;
    text-align: center;
    font-size: 1rem;
}

/* En-têtes */
th {
    background-color: #3da35d;
    color: white;
    font-size: 1.1rem;
}

/* Titres */
h2, h3 {
    text-align: center;
    color: #333;
    margin-bottom: 30px;
    font-size: 1.6rem;
}

/* Messages */
.message {
    max-width: 900px;
    margin: 30px auto;
    padding: 18px;
    border-radius: 8px;
    font-size: 1rem;
    text-align: center;
}

.message.success {
    background-color: #d4edda;
    color: #155724;
}

.message.error {
    background-color: #f8d7da;
    color: #721c24;
}


        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        .top-right-icon {
            position: absolute;
            top: 20px;
            right: 30px;
            }

        .top-right-icon img {
            width: 40px;
            height: 40px;
            cursor: pointer;
            transition: transform 0.3s;
            }

        .top-right-icon img:hover {
            transform: scale(1.2);

        }

        </style>
</head>
<body>
   
    <div class="sidebar">
        <div class="logo-container">
            <div class="logo"><a href="./accueil.php"><img src="../images/logo1.png" alt="logo"></a></div>
            <h2>e-Services</h2>
        </div>
        <div class="barre"></div>
        <div class="nav-menu">
            <div class="nav-item active">
              <ul >
                <li><a href="./accueil.php" class = "a_items">Accueil</a></li>
                <li><a href="./ue.php" class = "a_items">Unités d'enseignement</a></li>
                <li><a href="./Lafect.php" class = "a_items">Affectation</a></li>
                <li><a href="./creeV.php" class = "a_items">Compte Vacataire</a></li>
                <li><a href="./ue_vac.php" class = "a_items">Affectation UE / Vac</a></li>
                <li><a href="./emploi.php" class = "a_items">Emploi du Temps</a></li>
                <li><a href="./historique.php" class = "a_items">Historique</a></li>
                <li>
                    <a class="a_items dropdown-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
                        Fonctions Professeur
                    </a>
                    <ul id="profMenu" class="collapse list-unstyled ms-3">
                        <li><a href="./prof/souhait.php" class="a_items">Souhait</a></li>
                        <li><a href="./prof/notes.php" class="a_items">Notes</a></li>
                        <li><a href="./prof/historiquepf.php" class="a_items">Historique</a></li>
                    </ul>
                </li>
                
                <li><a href="../login.php" class = "a_items">Déconnexion</a></li>

              </ul>
            </div>
        </div>
    </div>
    
     
<div class="main-content">

<?php
$profs = $conn->query("SELECT DISTINCT u.id_utilisateur, u.nom, u.prenom 
                       FROM utilisateurs u 
                       JOIN affectations a ON u.id_utilisateur = a.id_utilisateur")
              ->fetchAll();

$filieres = $conn->query("SELECT id_filiere, nom_filiere FROM filieres")->fetchAll();

function showMessage($type, $text) {
    echo '<div class="message ' . $type . '">' . htmlspecialchars($text) . '</div>';
}

// Initialiser valeurs
$id_prof = $_POST['prof'] ?? null;
$id_filiere = $_POST['filiere'] ?? null;
$semestre = $_POST['semestre'] ?? null;
$afficher_formulaire = false;
$ues = [];
$jours = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
$heures = ['08:30', '10:30', '14:30', '16:30'];
$plages = ['08:30' => '10:30', '10:30' => '12:30', '14:30' => '16:30', '16:30' => '18:30'];

// Traitement : Générer
if (isset($_POST['generer'])) {
    $stmt = $conn->prepare("SELECT ue.id_ue, ue.nom 
                            FROM affectations a 
                            JOIN unites_enseignement ue ON a.id_ue = ue.id_ue 
                            WHERE a.id_utilisateur = ? AND a.id_filiere = ?");
    $stmt->execute([$id_prof, $id_filiere]);
    $ues = $stmt->fetchAll();

    if (empty($ues)) {
        showMessage('error', "Ce professeur n'a aucune affectation pour cette filière.");
    } else {
        $afficher_formulaire = true;
    }
}

// Traitement : Enregistrer
if (isset($_POST['enregistrer'])) {
    $stmt = $conn->prepare("SELECT ue.id_ue, ue.nom 
                            FROM affectations a 
                            JOIN unites_enseignement ue ON a.id_ue = ue.id_ue 
                            WHERE a.id_utilisateur = ? AND a.id_filiere = ?");
    $stmt->execute([$id_prof, $id_filiere]);
    $ues = $stmt->fetchAll();

    if (empty($ues)) {
        showMessage('error', "Erreur : aucune UE trouvée pour cet enseignant et cette filière.");
    } else {
        foreach ($jours as $jour) {
            foreach ($heures as $heure) {
                $ue = $_POST["ue_{$jour}_{$heure}"] ?? null;
                $salle = $_POST["salle_{$jour}_{$heure}"] ?? null;

                if (!empty($ue)) {
                    $heure_fin = $plages[$heure];
                    $stmt = $conn->prepare("INSERT INTO emplois_profs 
                        (id_utilisateur, id_filiere, semestre, jour_semaine, heure_debut, heure_fin, id_ue, salle) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$id_prof, $id_filiere, $semestre, $jour, $heure, $heure_fin, $ue, $salle]);
                }
            }
        }
        showMessage('success', "Emploi du temps enregistré avec succès !");
        $afficher_formulaire = true; // Garder le tableau visible
    }
}
?>

<!-- Étape 1 : Sélection -->
<h2>Générer l'emploi du temps</h2>
<form method="post">
    <label for="prof">Professeur :</label>
    <select name="prof" required>
        <?php foreach ($profs as $p): ?>
            <option value="<?= $p['id_utilisateur'] ?>" <?= $id_prof == $p['id_utilisateur'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['nom'] . ' ' . $p['prenom']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="filiere">Filière :</label>
    <select name="filiere" required>
        <?php foreach ($filieres as $f): ?>
            <option value="<?= $f['id_filiere'] ?>" <?= $id_filiere == $f['id_filiere'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($f['nom_filiere']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="semestre">Semestre :</label>
    <select name="semestre" required>
        <option value="S1" <?= $semestre == 'S1' ? 'selected' : '' ?>>S1</option>
        <option value="S2" <?= $semestre == 'S2' ? 'selected' : '' ?>>S2</option>
        <option value="S3" <?= $semestre == 'S3' ? 'selected' : '' ?>>S3</option>
        <option value="S4" <?= $semestre == 'S4' ? 'selected' : '' ?>>S4</option>
    </select>

    <button type="submit" name="generer">Générer</button>
</form>

<!-- Étape 2 : Affichage du tableau -->
<?php if ($afficher_formulaire): ?>
    <h3>Remplir l'emploi du temps</h3>
    <form method="post">
        <input type="hidden" name="prof" value="<?= $id_prof ?>">
        <input type="hidden" name="filiere" value="<?= $id_filiere ?>">
        <input type="hidden" name="semestre" value="<?= $semestre ?>">

        <table>
            <tr><th>Jour / Heure</th>
                <?php foreach ($heures as $heure): ?>
                    <th><?= $heure . ' - ' . $plages[$heure] ?></th>
                <?php endforeach; ?>
            </tr>

            <?php foreach ($jours as $jour): ?>
                <tr><th><?= $jour ?></th>
                    <?php foreach ($heures as $heure): ?>
                        <td>
                            <select name="ue_<?= $jour ?>_<?= $heure ?>">
                                <option value="">-- UE --</option>
                                <?php foreach ($ues as $ue): ?>
                                    <option value="<?= $ue['id_ue'] ?>"><?= htmlspecialchars($ue['nom']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="salle_<?= $jour ?>_<?= $heure ?>" placeholder="Salle">
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </table>

        <button type="submit" name="enregistrer">Enregistrer l'emploi</button>
    </form>
<?php endif; ?>

</div>
<script>
    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>

</body>
</html>
    
