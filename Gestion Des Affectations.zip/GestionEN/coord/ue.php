<?php
session_start();
require_once '../config/db.php'; // adapte le chemin si besoin

$user_id = $_SESSION['user_id'];
$filiere_id = $_SESSION['id_filiere']; // <-- tu peux récupérer ça dynamiquement aussi si besoin

// Récupérer les unités d'enseignement de la filière
$stmt_ue = $conn->prepare("
    SELECT ue.* ,COALESCE(h.cours, 0) AS cours,
                 COALESCE(h.td, 0) AS td,
                 COALESCE(h.tp, 0) AS tp , h.id
    FROM unites_enseignement ue
    JOIN module_filiere mf ON ue.id_ue= mf.id_module
    JOIN filieres f ON mf.id_filiere = f.id_filiere
    LEFT JOIN ue_h h ON ue.id_ue = h.ue_id
    WHERE f.id_filiere = ?
");
$stmt_ue->execute([$filiere_id]); 
$ues = $stmt_ue->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom'], $_POST['cours'])) {
    $nom = trim($_POST['nom']);
         $cours = (int)$_POST['cours'];
        $td    = (int)$_POST['td'];
        $tp    = (int)$_POST['tp'];

    try {
        // Vérifie si l'UE existe déjà
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM unites_enseignement WHERE nom = ?");
        $check_stmt->execute([$nom]);
        $exists = $check_stmt->fetchColumn();

        if ($exists) {
            header("Location: ue.php?error=exists");
            exit;
        }

        // Insertion de l'UE
        $stmt_insert = $conn->prepare("INSERT INTO unites_enseignement (nom) VALUES (?)");
        $stmt_insert->execute([$nom]);


        // Récupération de l'ID
        $last_id = $conn->lastInsertId();

        // Association à la filière
        $filiere_id = $_SESSION['id_filiere']; // à adapter
        $stmt_assoc = $conn->prepare("INSERT INTO module_filiere (id_module, id_filiere) VALUES (?, ?)");
        $stmt_assoc->execute([$last_id, $filiere_id]);

         // insertion charge

        $stmt_insert = $conn->prepare("INSERT INTO ue_h (ue_id , cours , td , tp) VALUES (?, ?, ?, ?)");
        $stmt_insert->execute([$last_id , $cours , $td , $tp]);
        header("Location: ue.php?success=1");
        exit;
    } catch (PDOException $e) {
        header("Location: ue.php?error=1");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
    <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}


/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}
   
    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }



/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
    transition: margin-left 0.3s ease;
}
        /*=======================================================================*/
                                           /*profile*/
        .search-bar {
            width: 100%;
            max-width: 400px;
            margin: 0 auto 30px auto;
            display: flex;
            align-items: center;
            position: relative;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ccc;
            border-radius: 30px;
            font-size: 16px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .search-bar input:focus {
            border-color: #27ae60;
            box-shadow: 0 0 8px rgba(39, 174, 96, 0.2);
            outline: none;
        }

        .search-bar::before {
            content: "🔍";
            position: absolute;
            left: 15px;
            font-size: 18px;
            color: #888;
        }

/*=========================================================================================================================== */

@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700&family=Roboto:wght@400;500&display=swap');

body {
    font-family: 'Roboto', Arial, sans-serif;
    background: linear-gradient(135deg, #e7ffe6 0%, #f8fafc 100%);
    margin: 0;
    padding: 0;
}

.container {
    max-width: 950px;
    margin: 40px auto;
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 32px rgba(52, 183, 101, 0.13);
    padding: 36px 24px 40px 24px;
}

h2, h2.ici {
    text-align: center;
    color: #27ae60;
    font-family: 'Montserrat', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 32px;
    margin-top: 0;
    letter-spacing: 1px;
}
h2.ici {
    margin-top: 48px;
    color: #1d7a38;
    font-size: 1.3rem;
}

.ue-scroll {
    max-height: 460px;
    overflow-y: auto;
    border: 1px solid #d4eed8;
    border-radius: 12px;
    background: #f5fcf7;
    box-shadow: 0 2px 12px rgba(52,183,101,0.07);
    margin-bottom: 35px;
}

table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    background: #f9fafb;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(52,183,101,0.07);
}

thead {
    background: linear-gradient(90deg, #27ae60 0%, #43e97b 100%);
    color: #fff;
}

th, td {
    padding: 15px 12px;
    text-align: left;
    font-size: 1.02rem;
    border-bottom: 1px solid #e4e9f2;
}
th {
    font-family: 'Montserrat', sans-serif;
    font-weight: 600;
    border-right: 1px solid #e4e9f2;
}
th:last-child {
    border-right: none;
}
tbody tr {
    transition: background 0.18s;
}
tbody tr:hover {
    background: #e7ffe6;
    cursor: pointer;
}
th:first-child, td:first-child {
    width: 58px;
    text-align: center;
    color: #27ae60;
    font-weight: 700;
}
tr:last-child td {
    border-bottom: none;
}

.form-container {
    width: 100%;
    padding: 32px 8px 8px 8px;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: #f7fafc;
    border-radius: 14px;
    box-shadow: 0 2px 10px rgba(52,183,101,0.06);
    margin-top: 10px;
}

form {
    width: 100%;
    max-width: 520px;
    margin: 0 auto;
}

form h3 {
    color: #27ae60;
    font-size: 1.1rem;
    margin-bottom: 18px;
    text-align: left;
    font-family: 'Montserrat', sans-serif;
}

form label {
    margin-bottom: 6px;
    margin-left: 6px;
    color: #555;
    font-weight: 500;
    font-size: 1rem;
    display: block;
}

form input[type="text"],
form input[type="number"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 18px;
    border: 1px solid #d4eed8;
    border-radius: 7px;
    font-size: 16px;
    transition: border-color 0.2s, box-shadow 0.2s;
    background: #f9fafd;
}

form input:focus {
    border-color: #27ae60;
    outline: none;
    box-shadow: 0 0 6px rgba(39,174,96,0.18);
}

form button {
    width: 100%;
    padding: 14px;
    background: linear-gradient(90deg, #27ae60 0%, #43e97b 100%);
    color: white;
    border: none;
    border-radius: 7px;
    font-size: 1.1rem;
    font-family: 'Montserrat', sans-serif;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(39,174,96,0.09);
    transition: background 0.2s;
    margin-top: 12px;
}
form button:hover {
    background: linear-gradient(90deg, #43e97b 0%, #27ae60 100%);
}

.message-success {
    text-align: center;
    color: #27ae60;
    background: #eafaf1;
    border: 1px solid #cbeedc;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 18px;
    font-weight: 500;
}
.message-warning {
    text-align: center;
    color: #d35400;
    background: #fff6e6;
    border: 1px solid #ffe0b2;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 18px;
    font-weight: 500;
}
.message-error {
    text-align: center;
    color: #e74c3c;
    background: #fdecea;
    border: 1px solid #fad7d7;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 18px;
    font-weight: 500;
}

/* Responsive */
@media (max-width: 900px) {
    .container {
        margin: 16px;
        padding: 20px 2vw;
    }
    h2 {
        font-size: 1.2rem;
    }
    form {
        max-width: 98vw;
    }
}
@media (max-width: 600px) {
    table, th, td {
        font-size: 0.88rem;
    }
    .container {
        padding: 6px 1vw;
    }
}
        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" ry="2"/>
        <path d="M8 2v4"/>
      </svg>
      <a href="./ue.php">Unités d'enseignement</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 6v6l4 2"/>
      </svg>
      <a href="./Lafect.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="7" width="16" height="10" rx="2"/>
        <path d="M16 3v4"/>
      </svg>
      <a href="./creeV.php">Compte Vacataire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 9l6 6 6-6"/>
      </svg>
      <a href="./ue_vac.php">Affectation UE / Vac</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h16"/>
        <path d="M12 2v16"/>
      </svg>
      <a href="./notes.php">Notes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <path d="M9 9h6v6H9z"/>
      </svg>
      <a href="./historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./prof/souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./prof/notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./prof/historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M16 17l-4-4-4 4"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
     
    <div class="main-content">
    <div class="search-bar">
    <input type="text" id="searchInput" placeholder=" Rechercher une UE..." onkeyup="filterTable()">
    </div>
    <script>
    function filterTable() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let rows = document.querySelectorAll("table tbody tr");

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(input) ? "" : "none";
        });
    }
    </script>
    <div class="container">
    <h2>Liste des Unités d'Enseignement</h2>
    <div class="ue-scroll">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom de l'UE</th>
                <th>Cours (h)</th>
                <th>TD (h)</th>
                <th>TP (h)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($ues) {
                foreach ($ues as $ue) {
                    echo "<tr>";
                    echo "<td data-label='ID'>" . htmlspecialchars($ue['id_ue']) . "</td>";
                    echo "<td data-label='Nom de l'UE'>" . htmlspecialchars($ue['nom']) . "</td>";
                    echo "<td data-label='Cours (h)'>" . htmlspecialchars($ue['cours']) . " h</td>";
                    echo "<td data-label='TD (h)'>" . htmlspecialchars($ue['td']) . " h</td>";
                    echo "<td data-label='TP (h)'>" . htmlspecialchars($ue['tp']) . " h</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4' style='text-align:center;'>Aucune unité d'enseignement trouvée.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
  

    <h2 class="ici">Ajouter une UE</h2>

    <?php if (isset($_GET['success'])): ?>
        <div class="message-success">✅ UE ajoutée avec succès !</div>
    <?php elseif (isset($_GET['error']) && $_GET['error'] === 'exists'): ?>
        <div class="message-warning">⚠️ Cette UE existe déjà.</div>
    <?php elseif (isset($_GET['error'])): ?>
        <div class="message-error">❌ Erreur lors de l'ajout de l'UE.</div>
    <?php endif; ?>

    <div class="form-container">
        <form action="ue.php" method="POST">
            <div>
                <label for="nom">Nom de l'UE :</label>
                <input type="text" name="nom" id="nom" required>
            </div>
            
            <h3>Volume Horaire (heures)</h3>
            <div>
                <label for="cour">Cours :</label>
                <input type="number" name="cours" id="cour" required>
            </div>
            <div>
                <label for="td">TD :</label>
                <input type="number" name="td" id="td">
            </div>
            <div>
                <label for="tp">TP :</label>
                <input type="number" name="tp" id="tp">
            </div>

            <button type="submit">Ajouter UE</button>
        </form>
    </div>
</div>

    </div>

        </div>
        <script>

             function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
     <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
    </html>
        
