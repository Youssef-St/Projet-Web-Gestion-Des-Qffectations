<?php
try {
    $conn = new PDO('mysql:host=localhost;dbname=gestion_affectations', 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

?>