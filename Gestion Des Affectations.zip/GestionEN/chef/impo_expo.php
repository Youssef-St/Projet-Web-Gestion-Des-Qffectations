<?php
session_start();
if (!isset($_SESSION['nom_utilisateurt'])) {
    header('Location: ./accueil.php'); // ou autre page
    exit;
}


require_once '../config/db.php'; // adapte le chemin si besoin

$id_utilisateurf = $_SESSION['user_id'];

$stmt = $conn->query("SELECT id FROM fichiers");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stmtCheck = $conn->prepare("SELECT 1 FROM fichiers_vus WHERE id_utilisateur = ? AND id_fichier = ?");
    $stmtCheck->execute([$id_utilisateurf, $row['id']]);
    if (!$stmtCheck->fetch()) {
        $stmtInsert = $conn->prepare("INSERT INTO fichiers_vus (id_utilisateur, id_fichier) VALUES (?, ?)");
        $stmtInsert->execute([$id_utilisateurf, $row['id']]);
    }
}

// Crée le dossier uploads/ s'il n'existe pas
if (!is_dir('../uploads')) {
    mkdir('../uploads', 0777, true);
}

// Traitement de l'upload
if (isset($_POST['upload'])) {
    $fileName = basename($_FILES['excel_file']['name']);
    $fileTmpName = $_FILES['excel_file']['tmp_name'];

    // Destination finale
    $destination = __DIR__ . '/../uploads/' . $fileName;

    if (move_uploaded_file($fileTmpName, $destination)) {
        $nomUtilisateur = $_SESSION['nom_utilisateurt'] ?? 'Inconnu';
        $stmt = $conn->prepare("INSERT INTO fichiers (nom_fichier, date_upload, nom_utilisateur, vu) VALUES (?, NOW(), ?, 0)");
        $stmt->execute([$fileName, $nomUtilisateur]);
        
    } else {
        $_SESSION['error'] = 'Erreur lors de l\'upload du fichier.';
    }
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

// Traitement du téléchargement
if (isset($_GET['download'])) {
    $fileName = basename($_GET['download']);
    $filePath = __DIR__ . '/../uploads/' . $fileName;

    if (file_exists($filePath) && is_file($filePath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    } else {
        header("HTTP/1.0 404 Not Found");
        die("Fichier non trouvé: " . htmlspecialchars($fileName));
    }
}
if (isset($_GET['delete'])) {
    
    $fileName = basename($_GET['delete']);

        // Récupérer l'id du fichier
        $stmt = $conn->prepare("SELECT id FROM fichiers WHERE nom_fichier = ?");
        $stmt->execute([$fileName]);
        $file = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($file && $file['nom_utilisateur'] === $_SESSION['nom_utilisateurt']) {
            $idFichier = $file['id'];

            // Supprimer d’abord les références dans fichiers_vus
            $stmt = $conn->prepare("DELETE FROM fichiers_vus WHERE id_fichier = ?");
            $stmt->execute([$idFichier]);

            // Ensuite supprimer le fichier physique
            $filePath = __DIR__ . '/../uploads/' . $fileName;
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            // Supprimer l'entrée dans fichiers
            $stmt = $conn->prepare("DELETE FROM fichiers WHERE id = ?");
            $stmt->execute([$idFichier]);
        }


    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <title>Plateforme e-Services</title>
    <style>
    body {
      display: flex;
      background-color: #f0f2f5;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
      color: white;
      padding: 25px 0;
      height: 100vh;
      transition: width 0.3s ease;
      overflow: hidden;
      position: fixed;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar.collapsed {
      width: 60px;
    }

    .toggle-button {
      position: absolute;
      top: 10px;
      right: 15px;
      background-color: rgb(83, 190, 34);
      border: 0.1px solid rgb(83, 190, 34);
      border-radius: 4px;
      cursor: pointer;
      padding: 4px;
      z-index: 1000;
    }

    .barre {
      height: 3px;
      width: 30px;
      background-color: white;
      margin: 15px auto;
      border-radius: 2px;
      transition: width 0.3s ease;
    }

    .sidebar:hover .barre {
      width: 80%;
    }

    .logo-container {
    text-align: center;
    padding: 20px;
    transition: opacity 0.3s, height 0.3s;
    }

    .sidebar.collapsed .logo-container {
    opacity: 0;
    height: 0;
    overflow: hidden;
    padding: 0;
    }
       
    .logo img {
      width: 100%;
      height: 120px;
      border-radius: 50%;
      margin: -25px auto;
      transition: transform 0.3s ease;
    }

    .logo img:hover {
      transform: scale(1.05);
    }

    .sidebar ul.menu {
      list-style: none;
      padding: 0;
      margin-top: 30px;
    }

    .sidebar ul.menu li {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      white-space: nowrap;
      transition: 0.3s;
    }

    .sidebar.collapsed ul.menu li {
      justify-content: center;
      padding: 12px 0;
    }

    .sidebar ul.menu li svg {
      margin-right: 10px;
      min-width: 20px;
    }

    .sidebar.collapsed ul.menu li a {
      display: none;
    }

    .sidebar ul.menu li a {
      text-decoration: none;
      color: #e0f2f1;
      font-size: 16px;
      transition: color 0.3s;
    }

    .sidebar ul.menu li a:hover {
      color: #ffffff;
    }



    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }


/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}
        /*=======================================================*/

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        h1, h2 {
            text-align: center;
            color: #2c3e50;
        }
        form {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        input[type="file"] {
            padding: 8px;
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }



                /* Responsive */
                @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        a.icon-btn {
            font-size: 20px;
            text-decoration: none;
            margin: 0 6px;
            padding: 6px 10px;
            border-radius: 6px;
            display: inline-block;
            transition: background 0.3s;
        }

        a.icon-btn.download {
            color: white;
        }


        a.icon-btn.delete {
            color: white;
        }


        ul .collapse {
            background-color: #f8f9fa; /* plus doux que blanc pur */
            border-radius: 8px;
            padding: 8px 0;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
            margin-top: 4px;
            transition: all 0.3s ease;
        }

        ul .collapse li {
            padding: 4px 16px;
        }

        ul .collapse li a {
            display: block;
            color: #343a40;
            text-decoration: none;
            padding: 6px 10px;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        ul .collapse li a:hover {
            background-color: #e2e6ea;
            color: #000;
        }

    </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="7" r="4"/>
        <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
      </svg>
      <a href="./UE_PF.php">Liste Professeur/UE</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
        <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
        <path d="M9 10h6"/>
        <path d="M9 14h6"/>
      </svg>
      <a href="./affectation.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="7" width="18" height="10" rx="2"/>
        <line x1="7" y1="11" x2="17" y2="11"/>
      </svg>
      <a href="./valid_decli.php">Valider le choix</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h16v2H4z"/>
        <path d="M4 8h16v2H4z"/>
        <path d="M4 12h16v2H4z"/>
        <path d="M4 16h16v2H4z"/>
      </svg>
      <a href="./chargeh.php">Charge horaire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 17l4-4-4-4M16 17V7"/>
      </svg>
      <a href="./vacant.php">UE vacantes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="historique.php">Historique</a>
    </li>
    <!-- Dropdown Professeur -->
    <li class="dropdown">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 2a4 4 0 0 1 4 4v2a4 4 0 0 1-4 4 4 4 0 0 1-4-4V6a4 4 0 0 1 4-4z"/>
        <path d="M6 13v-2a6 6 0 0 1 12 0v2"/>
      </svg>
      <a class="a_items dropdown-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        Fonctions Professeur
      </a>
      <ul id="profMenu" class="collapse list-unstyled ms-3">
        <li><a href="./prof/souhait.php">Souhait</a></li>
        <li><a href="./prof/notes.php">Notes</a></li>
        <li><a href="./prof/historiquepf.php">Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
    
     
    <div class="main-content">


    <div class="container">
    <h1>📄 Partage de Fichiers Excel</h1>

    <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

    <form method="post" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xlsx" required>
        <button type="submit" name="upload">Envoyer</button>
    </form>

    <h2>Fichiers partagés 📚</h2>
    <table>
    <tr>
            <th>Nom du fichier</th>
            <th>Date d'upload</th>
            <th>Envoyé par</th>
            <th>Action</th>
        </tr>
        <?php
            $stmt = $conn->query("SELECT * FROM fichiers ORDER BY date_upload DESC");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['nom_fichier']) . "</td>";
                echo "<td>" . $row['date_upload'] . "</td>";
                echo "<td>" . htmlspecialchars($row['nom_utilisateur']) . "</td>";
                echo "<td>";
                echo "<a  class='icon-btn download' href='?download=" . urlencode($row['nom_fichier']) . "' title='Télécharger'><img src='img/tele.png' alt='📥'></a>";
                if ($_SESSION['nom_utilisateurt'] === $row['nom_utilisateur']) {
                    echo "<a class='icon-btn delete' href='?delete=" . urlencode($row['nom_fichier']) . "' title='Supprimer' onclick=\"return confirm('Supprimer ce fichier ?')\"><img src='img/supp.png' alt='🗑️'></a>";
                }
                echo "</td>";
                echo "</tr>";
            }
        ?>
    </table>
</div>
    </div>
     <script>

        function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
</body>
</html>
    
