<?php
session_start();
require_once '../config/db.php';

$id_chef = $_SESSION['user_id'];
$departement_id = $_SESSION['departement_id'];

// Récupérer professeurs, UEs et filières
$stmt = $conn->prepare("SELECT id_utilisateur, nom, prenom FROM utilisateurs WHERE ( role_id = 2 OR role_id = 3 OR role_id = 4 ) AND departement_id = ?");
$stmt->execute([$departement_id]);
$professeurs = $stmt->fetchAll();
$stmt = $conn->prepare("SELECT id_ue, nom FROM unites_enseignement WHERE departement_id = ?");
$stmt->execute([$departement_id]);
$ues = $stmt->fetchAll();
$filieres = $conn->query("SELECT id_filiere, nom_filiere FROM filieres")->fetchAll();

// Ajouter une affectation
     
    if (isset($_POST['ajouter_multi'])) {
    foreach ($_POST['ue_ids'] as $id_ue) {
        // Vérifie si l'utilisateur a bien rempli cette ligne
        if (
            empty($_POST['professeurs'][$id_ue]) ||
            empty($_POST['filieres'][$id_ue]) ||
            empty($_POST['annees'][$id_ue]) ||
            empty($_POST['types'][$id_ue])
        ) {
            continue; // Ignore cette ligne incomplète
        }

        $id_prof = $_POST['professeurs'][$id_ue];
        $id_filiere = $_POST['filieres'][$id_ue];
        $annee = $_POST['annees'][$id_ue];

        $types = $_POST['types'][$id_ue] ;
        // Initialiser les colonnes cours/td/tp à 0
        $cours = in_array('Cours', $types) ? 1 : 0;
        $td    = in_array('TD', $types) ? 1 : 0;
        $tp    = in_array('TP', $types) ? 1 : 0;

        // Vérifie si une affectation identique existe déjà
        $check = $conn->prepare("SELECT COUNT(*) FROM affectations 
                                WHERE id_utilisateur = ? AND id_ue = ?");
        $check->execute([$id_prof, $id_ue]);
        if ($check->fetchColumn() > 0) continue;

        // Insérer l'affectation avec colonnes cours/td/tp
        $stmt = $conn->prepare("INSERT INTO affectations (id_utilisateur, id_ue, id_filiere, annee_universitaire, statut, date_affectation, id_chef, cours, td, tp) 
                                VALUES (?, ?, ?, ?, 'Titulaire', NOW(), ?, ?, ?, ?)");
        $stmt->execute([$id_prof, $id_ue, $id_filiere, $annee, $id_chef, $cours, $td, $tp]);


        // Récupérer volumes horaires
        $stmtVol = $conn->prepare("SELECT cours, td, tp FROM ue_h WHERE id = ?");
        $stmtVol->execute([$id_ue]);
        $vol = $stmtVol->fetch();

        $volume_horaire = 0;
        if ($vol) {
            if ($cours) { $volume_horaire += $vol['cours'];}
            if ($td) {  $volume_horaire += $vol['td'];} 
            if ($tp) {   $volume_horaire += $vol['tp'];}
        }

        // Mettre à jour la charge horaire
        $update = $conn->prepare("UPDATE utilisateurs SET charge_horaire = charge_horaire + ? WHERE id_utilisateur = ?");
        $update->execute([$volume_horaire, $id_prof]);

        }
        header("Location: " . $_SERVER['PHP_SELF']);
    exit;


}



// Supprimer une affectation
if (isset($_POST['supprimer'])) {
    $id_affectation = $_POST['id_affectation'];

    // Récupérer l'affectation
    $stmt = $conn->prepare("SELECT id_utilisateur, id_ue, cours, td, tp FROM affectations WHERE id_affectation = ?");
    $stmt->execute([$id_affectation]);
    $aff = $stmt->fetch();

    if ($aff) {
        // Récupérer les volumes horaires
        $stmtVol = $conn->prepare("SELECT cours, td, tp FROM ue_h WHERE id = ?");
        $stmtVol->execute([$aff['id_ue']]);
        $vol = $stmtVol->fetch();

        $volume_horaire = 0;
            if ($vol) {
                if ($aff['cours']) {
                    $volume_horaire += $vol['cours'];
                }
                if ($aff['td']) {
                    $volume_horaire += $vol['td'];
                }
                if ($aff['tp']) {
                    $volume_horaire += $vol['tp'];
                }
            }

        // Supprimer l'affectation
        $delete = $conn->prepare("DELETE FROM affectations WHERE id_affectation = ?");
        $delete->execute([$id_affectation]);

        // Mettre à jour la charge horaire
        $update = $conn->prepare("UPDATE utilisateurs SET charge_horaire = charge_horaire - ? WHERE id_utilisateur = ?");
        $update->execute([$volume_horaire, $aff['id_utilisateur']]);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}



// Afficher les affectations
$stmt = $conn->prepare("SELECT a.id_affectation, u.nom AS nom_prof, ue.nom AS nom_ue, f.nom_filiere,
                               a.annee_universitaire, a.statut, a.date_affectation,
                               a.cours, a.td, a.tp
                        FROM affectations a
                        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                        JOIN unites_enseignement ue ON a.id_ue = ue.id_ue
                        JOIN filieres f ON a.id_filiere = f.id_filiere
                        WHERE a.id_chef = ?");

$stmt->execute([$id_chef]);
$affectations = $stmt->fetchAll();
?>



<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
      <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}

.main-content {
  margin-left: 230px;
  width: 100%;
  height : 100%;
  transition: margin-left 0.3s ease;
  background-color: white;
}

.sidebar.collapsed ~ .main-content,
.sidebar.collapsed + .main-content {
  margin-left: 60px;
}

/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}
     
/*=================================================================*/



h1, h2 {
    text-align: center;
    margin: 20px 0;
    color: #2c3e50;
    font-weight: 600;
}


/* Scroll horizontal pour les tableaux larges */
.ue-scroll {
    max-height: 600px; /* ← tu peux ajuster cette hauteur */
    overflow-y: auto;
    border: 1px solid #ccc;
    border-radius: 8px;
    background: #fff;
}



/* Harmoniser l'affichage des champs dans les cellules */
select,
input[type="text"] {
    width: 100%;
    padding: 6px 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

/* Affichage plus lisible des checkboxes */
td label {
    display: inline-block;
    margin: 3px 5px;
}


        .container {
            margin: auto;
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            font-family: 'Segoe UI', sans-serif;

        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;


        }
        .total {
            margin-top: 20px;
            font-weight: bold;
            font-size: 18px;
            text-align: right;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .ici {
            padding: 10px 20px;
            background-color:rgb(20, 18, 19);
            color: white;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
            cursor: pointer;  
        }

        .ici:hover{
            background-color:rgb(104, 104, 104); 
        }






button.btn-supprimer {
    background: #e74c3c;
    border: none;
    color: white;
    padding: 8px 14px;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button.btn-supprimer:hover {
    background: #c0392b;
}

.table-container {
    width: 95%;
    margin: 20px auto 50px;
    overflow-x: auto;
    background: #fff;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.06);
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 1em;
    min-width: 700px;
}

thead {
    background-color: #3da35d;;
    color: white;
}

th, td {
    padding: 14px 10px;
    text-align: center;
    border-bottom: 1px solid #ecf0f1;
}

tbody tr:hover {
    background-color: #f9fbff;
    transition: background-color 0.2s ease;
}

            
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }


    </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <!-- Modern menu with icons -->
  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="7" r="4"/>
        <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
      </svg>
      <a href="./UE_PF.php">Liste Professeur/UE</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
        <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
        <path d="M9 10h6"/>
        <path d="M9 14h6"/>
      </svg>
      <a href="./affectation.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="7" width="18" height="10" rx="2"/>
        <line x1="7" y1="11" x2="17" y2="11"/>
      </svg>
      <a href="./valid_decli.php">Valider le choix</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h16v2H4z"/>
        <path d="M4 8h16v2H4z"/>
        <path d="M4 12h16v2H4z"/>
        <path d="M4 16h16v2H4z"/>
      </svg>
      <a href="./chargeh.php">Charge horaire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 17l4-4-4-4M16 17V7"/>
      </svg>
      <a href="./vacant.php">UE vacantes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./prof/souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./prof/notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./prof/historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>

    <div class="main-content"> 
    <h1>Gestion des Affectations</h1><br>

    <!-- Formulaire d'ajout d'affectation -->
    <div class="container">

        <form method="post"  >
            <h2>Affecter des professeurs aux UEs</h2>
            <div class="ue-scroll">
            <table border="1" cellpadding="8" cellspacing="0">
                <thead>
                    <tr>
                        <th>UE</th>
                        <th>Professeur</th>
                        <th>Filière</th>
                        <th>Année</th>
                        <th>Types (multi)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ues as $ue): ?>
                        <tr class="ue-row" data-ue-id="<?= $ue['id_ue'] ?>">
                            <td>
                                <?= htmlspecialchars($ue['nom']) ?>
                                <input type="hidden" name="ue_ids[]" value="<?= $ue['id_ue'] ?>">
                            </td>
                            <td>
                                <select name="professeurs[<?= $ue['id_ue'] ?>]" >
                                    <option value="">--Choisir--</option>
                                    <?php foreach ($professeurs as $prof): ?>
                                        <option value="<?= $prof['id_utilisateur'] ?>">
                                            <?= htmlspecialchars($prof['nom'] . ' ' . $prof['prenom']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="filieres[<?= $ue['id_ue'] ?>]" >
                                    <option value="">--Filiere--</option>
                                    <?php foreach ($filieres as $filiere): ?>
                                        <option value="<?= $filiere['id_filiere'] ?>"><?= htmlspecialchars($filiere['nom_filiere']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="text" name="annees[<?= $ue['id_ue'] ?>]" placeholder="2024-2025" ></td>
                            <td>
                                <label><input type="checkbox" class="type-cours" name="types[<?= $ue['id_ue'] ?>][]" value="Cours"> Cours</label>
                                <label><input type="checkbox" class="type-td" name="types[<?= $ue['id_ue'] ?>][]" value="TD"> TD</label>
                                <label><input type="checkbox" class="type-tp" name="types[<?= $ue['id_ue'] ?>][]" value="TP"> TP</label>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            


            <button type="submit" name="ajouter_multi">Valider toutes les affectations</button>
        </form>

   </div>



    <!-- Tableau des affectations -->
    <h2>Liste des Affectations</h2>
    <div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Professeur</th>
                <th>UE</th>
                <th>Filière</th>
                <th>Année</th>
                <th>Statut</th>
                <th>Type</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($affectations as $aff): ?>
            <tr>
                <td><?= htmlspecialchars($aff['nom_prof']) ?></td>
                <td><?= htmlspecialchars($aff['nom_ue']) ?></td>
                <td><?= htmlspecialchars($aff['nom_filiere']) ?></td>
                <td><?= htmlspecialchars($aff['annee_universitaire']) ?></td>
                <td><?= htmlspecialchars($aff['statut']) ?></td>
                <td>    <?php
                        $types = [];
                        if ($aff['cours']) $types[] = 'Cours';
                        if ($aff['td'])    $types[] = 'TD';
                        if ($aff['tp'])    $types[] = 'TP';
                        echo implode(', ', $types);
                    ?></td>
                <td><?= htmlspecialchars($aff['date_affectation']) ?></td>
                <td>
                    <form action="" method="POST" style="display:inline;">
                        <input type="hidden" name="id_affectation" value="<?= $aff['id_affectation'] ?>">
                        <button type="submit" name="supprimer" class="btn-supprimer">Supprimer</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    </div>
        <script>
         function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });

      </script>
      <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>