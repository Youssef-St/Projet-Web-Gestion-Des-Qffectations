<?php
require_once '../config/db.php';
session_start();

// Récupérer les paramètres existants pour le formulaire
$stmt = $conn->prepare("SELECT actif, date_limite FROM parametres_choix WHERE id_departement = ?");
$stmt->execute([$_SESSION['departement_id']]);
$param = $stmt->fetch();

$param_actif = $param ? (bool)$param['actif'] : false;
$param_date = $param ? date('Y-m-d\TH:i', strtotime($param['date_limite'])) : '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['maj_activation'])) {
    $actif = isset($_POST['actif']) ? 1 : 0;
    $date_limite = $_POST['date_limite'];

    $stmt = $conn->prepare("DELETE FROM parametres_choix WHERE id_departement = ?");
    $stmt->execute([$_SESSION['departement_id']]);    

    $stmt = $conn->prepare("REPLACE INTO parametres_choix (id_departement, actif, date_limite) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['departement_id'], $actif, $date_limite]);

    $_SESSION['message'] = "✅ Paramètres mis à jour.";
    header("Location: valid_decli.php"); // Rechargement pour éviter renvoi formulaire
    exit();
}

// Liste des années
$annees_stmt = $conn->query("SELECT DISTINCT annee_universitaire FROM choix_professeurs ORDER BY annee_universitaire DESC");
$annees = $annees_stmt->fetchAll(PDO::FETCH_COLUMN);

$annee_selectionnee = $_POST['annee_univ'] ?? null;
$choix = [];
if ($annee_selectionnee) {
    $stmt = $conn->prepare("
    SELECT 
        u.id_utilisateur, u.nom, u.prenom,
        cp.id_choix, cp.statut, cp.id_ue,cp.filiere_id, f.nom_filiere,
        ue.nom AS ue_nom, cp.cours, cp.td, cp.tp,

        -- Calcul du volume horaire = sum(cours * cp.cours + td * cp.td + tp * cp.tp)
        COALESCE(uh.cours, 0) * cp.cours +
        COALESCE(uh.td, 0) * cp.td +
        COALESCE(uh.tp, 0) * cp.tp AS volume_horaire,
        -- Charge totale par prof sur l'année universitaire (somme des volumes horaires par UE)
        SUM(
            COALESCE(uh.cours, 0) * cp.cours +
            COALESCE(uh.td, 0) * cp.td +
            COALESCE(uh.tp, 0) * cp.tp
        ) OVER (PARTITION BY u.id_utilisateur) AS charge
    FROM utilisateurs u
    JOIN choix_professeurs cp ON u.id_utilisateur = cp.id_utilisateur
    JOIN filieres f ON cp.filiere_id = f.id_filiere
    JOIN unites_enseignement ue ON cp.id_ue = ue.id_ue
    LEFT JOIN ue_h uh ON cp.id_ue = uh.ue_id
    JOIN roles r ON r.id_role = u.role_id
    WHERE cp.annee_universitaire = ? AND u.departement_id = ?
    ORDER BY charge < 120 DESC, charge ASC, u.nom
 ");


    $stmt->execute([$annee_selectionnee , $_SESSION['departement_id']]);
    $choix = $stmt->fetchAll(PDO::FETCH_ASSOC); // <- ici la correction
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id_choix'])) {
    $id_choix = $_POST['id_choix'];
    $action = $_POST['action'];

    $stmt = $conn->prepare("
    SELECT id_utilisateur, id_ue, annee_universitaire, cours, td, tp , filiere_id
    FROM choix_professeurs
    WHERE id_choix = ?
   ");


    $stmt->execute([$id_choix]);
    $choix_unique = $stmt->fetch(PDO::FETCH_ASSOC); // <-- nouveau nom ici

    if ($choix_unique) {
        if ($action === 'valider') {
            // Vérifier si l'UE est déjà affectée à un autre professeur pour la même année et le même type
           $stmt = $conn->prepare("
            SELECT u.nom, u.prenom, a.cours, a.td, a.tp
            FROM affectations a
            JOIN utilisateurs u ON u.id_utilisateur = a.id_utilisateur
            WHERE a.id_ue = ? 
            AND a.annee_universitaire = ? 
            AND a.cours = ? 
            AND a.td = ? 
            AND a.tp = ?
            AND a.id_filiere = ?
            AND a.id_utilisateur != ?
        ");
        $stmt->execute([
            $choix_unique['id_ue'],
            $choix_unique['annee_universitaire'],
            $choix_unique['cours'],
            $choix_unique['td'],
            $choix_unique['tp'],
            $choix_unique['filiere_id'],
            $choix_unique['id_utilisateur']
        ]);

        $affecte = $stmt->fetch(PDO::FETCH_ASSOC);

        
            if ($affecte) {
                if ($affecte) {
                    $_SESSION['message'] = "Cette UE est déjà affectée à <u>{$affecte['nom']} {$affecte['prenom']}</u> avec le type d'affectation : <b>{$affecte['type_affectation']}</b>.";
                }
                
            } else {
                // Mettre à jour le choix comme validé
                $stmt = $conn->prepare("UPDATE choix_professeurs SET statut = 'valide' WHERE id_choix = ?");
                $stmt->execute([$id_choix]);
        
                // Ajouter dans la table des affectations si pas encore présent
                // Vérifie si l'affectation existe déjà
                $stmt = $conn->prepare("
                    SELECT COUNT(*) FROM affectations 
                    WHERE id_utilisateur = ? 
                      AND id_ue = ? 
                      AND annee_universitaire = ? 
                      AND id_filiere = ? 
                      AND cours = ? 
                      AND td = ? 
                      AND tp = ?
                ");
                $stmt->execute([
                    $choix_unique['id_utilisateur'],
                    $choix_unique['id_ue'],
                    $choix_unique['annee_universitaire'],
                    $choix_unique['filiere_id'],
                    $choix_unique['cours'],
                    $choix_unique['td'],
                    $choix_unique['tp']
                ]);

                $existe = $stmt->fetchColumn();

                if ($existe == 0) {
                    // Mettre à jour le choix comme validé
                    $stmt = $conn->prepare("UPDATE choix_professeurs SET statut = 'valide' WHERE id_choix = ?");
                    $stmt->execute([$id_choix]);

                    // Ajouter dans la table des affectations
                    $stmt = $conn->prepare("
                        INSERT INTO affectations (id_utilisateur, id_ue, annee_universitaire, id_filiere ,cours, td, tp , id_chef ,statut)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Titulaire')
                    ");
                    $stmt->execute([
                        $choix_unique['id_utilisateur'],
                        $choix_unique['id_ue'],
                        $choix_unique['annee_universitaire'],
                        $choix_unique['filiere_id'],
                        $choix_unique['cours'],
                        $choix_unique['td'],
                        $choix_unique['tp'],
                        $_SESSION['user_id']
                    ]);
                }


        
                
            }
        }
         elseif ($action === 'decliner') {
            $stmt = $conn->prepare("UPDATE choix_professeurs SET statut = 'refuse' WHERE id_choix = ?");
            $stmt->execute([$id_choix]);
        }
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
       <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}


.sidebar.collapsed ~ .main-content,
.sidebar.collapsed + .main-content {
  margin-left: 60px;
}

/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}
/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}
     

/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}

        /*`==========================================================0*/


@import url('https://fonts.googleapis.com/css2?family=Inter:wght@500;700&display=swap');

/* Corps général */
body {
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(120deg, #e3f0ff 0%, #f5f7fa 100%);
    margin: 0;
    padding: 0;
    color: #24344d;
}

/* Titre principal */
h2 {
    text-align: center;
    color: #108fe3;
    margin-bottom: 36px;
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size: 2.1em;
    font-weight: 700;
    letter-spacing: 0.01em;
    background: linear-gradient(90deg, #108fe3 75%, #25c16f 110%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    border-bottom: none;
    padding-bottom: 0;
}

/* Container de la table */
.table-container {
    max-width: 1100px;
    margin: 0 auto;
    background: #fff;
    padding: 24px 28px;
    border-radius: 24px;
    box-shadow: 0 10px 32px rgba(44,63,150,0.10);
    border: 1.5px solid #e3f0fa;
    overflow: hidden;
}

/* Table */
table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 15px;
    font-size: 1.09rem;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 2px 18px rgba(44,63,150,0.04);
    background: #fff;
}

thead {
    background: linear-gradient(90deg, #eaf6fb 80%, #e3f0ff 100%);
    color: #218c74;
}

thead th {
    font-weight: 700;
    padding: 18px;
    text-align: center;
    border-bottom: 2px solid #b9d6fa;
    font-size: 1.11rem;
    background: none;
    color: #108fe3;
    letter-spacing: 0.01em;
}

tbody tr {
    background: #fafdff;
    transition: background-color 0.19s;
}

tbody tr:nth-child(even) {
    background-color: #f3f7fa;
}

tbody tr:hover {
    background: #eaf3fb;
}

tbody td {
    padding: 15px 18px;
    border-bottom: 1px solid #e2e8f0;
    color: #24344d;
    font-size: 1.05rem;
    vertical-align: middle;
    text-align: center;
}

/* Badges modernes */
.badge {
    display: inline-block;
    padding: 5px 12px;
    font-size: 0.87em;
    border-radius: 16px;
    margin-left: 10px;
    font-weight: 600;
}
.badge-success { background: #d2f8e1; color: #218c74; }
.badge-danger { background: #ffd7d7; color: #b91c1c; }
.badge-pending { background: #fff3cd; color: #856404; }

/* Boutons modernes */
.btn-sm {
    padding: 6px 16px;
    font-size: 0.98rem;
    margin-left: 6px;
    border-radius: 10px;
    border: none;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.14s, color 0.14s;
    box-shadow: 0 2px 8px rgba(44,150,63,0.11);
}
.btn-validate {
    background: linear-gradient(90deg, #25c16f 70%, #108fe3 120%);
    color: #fff;
}
.btn-decline {
    background: linear-gradient(90deg, #f44336 70%, #ffb400 120%);
    color: #fff;
}
.btn-sm:hover {
    opacity: 0.93;
    box-shadow: 0 4px 16px rgba(44, 150, 63, 0.13);
}

/* Sélecteur moderne */
.form-select {
    border-radius: 0.7rem;
    border: 1.2px solid #108fe3;
    padding: 7px 18px;
    font-size: 1.06rem;
    background: #f6fafd;
    color: #108fe3;
    font-weight: 500;
    transition: border-color 0.18s;
}
.form-select:focus {
    border-color: #25c16f;
    background: #eaf3fb;
    outline: none;
}

/* Alertes */
.alert-danger {
    background: linear-gradient(90deg, #ffd7d7 70%, #ffe6e6 100%);
    color: #b91c1c;
    border-radius: 12px;
    font-weight: 600;
    margin-bottom: 18px;
    padding: 12px 0;
}

/* Card paramètre */
.card {
    border-radius: 16px;
    box-shadow: 0 4px 18px rgba(44,63,150,0.07);
    border: 1px solid #e3f0fa;
}
.card-header {
    font-weight: 700;
    font-size: 1.13em;
    letter-spacing: 0.01em;
    background: linear-gradient(90deg, #25c16f 70%, #108fe3 120%) !important;
    color: #fff !important;
    border-radius: 16px 16px 0 0 !important;
    padding: 18px !important;
}
.card-body {
    padding: 18px;
}

/* Responsive */
@media (max-width: 900px) {
    .table-container {
        padding: 10px 4px;
        border-radius: 10px;
    }
    table thead th,
    table tbody td {
        padding: 8px 4px;
        font-size: 0.97rem;
    }
    h2 {
        font-size: 1.3em;
        margin-bottom: 16px;
    }
    .card-header, .card-body {
        padding: 8px !important;
    }
}
        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="./accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="7" r="4"/>
        <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
      </svg>
      <a href="./UE_PF.php">Liste Professeur/UE</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
        <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
        <path d="M9 10h6"/>
        <path d="M9 14h6"/>
      </svg>
      <a href="./affectation.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="7" width="18" height="10" rx="2"/>
        <line x1="7" y1="11" x2="17" y2="11"/>
      </svg>
      <a href="./valid_decli.php">Valider le choix</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h16v2H4z"/>
        <path d="M4 8h16v2H4z"/>
        <path d="M4 12h16v2H4z"/>
        <path d="M4 16h16v2H4z"/>
      </svg>
      <a href="./chargeh.php">Charge horaire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 17l4-4-4-4M16 17V7"/>
      </svg>
      <a href="./vacant.php">UE vacantes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./prof/souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./prof/notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./prof/historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../login.php">Déconnexion</a>
    </li>
  </ul>
</div>

     
    <div class="main-content">
    <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-danger text-center fw-bold">
        <?= $_SESSION['message'] ?>
    </div>
    <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <h2>Validation des Choix des Professeurs</h2>

<div class="table-container">
<form method="post" class="mb-4">
    <label for="annee_univ" class="form-label fw-bold">Sélectionner une année universitaire :</label>
    <div class="input-group" style="max-width: 300px;">
        <select name="annee_univ" id="annee_univ" class="form-select" required>
            <option value="">-- Choisir une année --</option>
            <?php foreach ($annees as $annee): ?>
                <option value="<?= $annee ?>" <?= $annee == $annee_selectionnee ? 'selected' : '' ?>>
                    <?= htmlspecialchars($annee) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Afficher</button>
    </div>
</form>
<!-- ✅ FORMULAIRE MODERNE AVEC BOOTSTRAP -->

<div class="card shadow-sm mb-4 mt-4">
    <div class="card-header bg-info text-white" style = "background-color :#3da35d; ">
        <i class="bi bi-gear-fill"></i> Paramètres d'activation des souhaits
    </div>
    <div class="card-body">
        <form method="post" class="row g-3">
            <div class="col-md-6">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="actif" id="actifSwitch" value="1" <?= $param_actif ? 'checked' : '' ?>>
                    <label class="form-check-label" for="actifSwitch">Activer la page des souhaits</label>
                </div>
            </div>
            <div class="col-md-6">
                <label for="date_limite" class="form-label">Date limite de saisie :</label>
                <input type="datetime-local" class="form-control" name="date_limite" id="date_limite" value="<?= $param_date ?>" required>
            </div>
            <div class="col-12 mt-3">
                <button type="submit" name="maj_activation" class="btn btn-primary">
                    <i class="bi bi-save"></i> Mettre à jour
                </button>
            </div>
        </form>
    </div>
</div>

<?php if ($annee_selectionnee): ?>
    <h5 class="text-success">Choix pour l'année universitaire : <?= htmlspecialchars($annee_selectionnee) ?></h5>
    <table class="table table-bordered shadow-sm">
        <thead class="table-dark">
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Charge Horaire</th>
                <th>Filiere</th>
                <th>Unités Choisies</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $groupes = [];
        foreach ($choix as $c) {
            $groupes[$c['id_utilisateur']]['nom'] = $c['nom'];
            $groupes[$c['id_utilisateur']]['prenom'] = $c['prenom'];
            $groupes[$c['id_utilisateur']]['charge'] = $c['charge'];
            $groupes[$c['id_utilisateur']]['nom_filiere'][] = ['nom_filiere' => $c['nom_filiere'] ];

            $groupes[$c['id_utilisateur']]['ues'][] = [
                'id_choix' => $c['id_choix'],
                'nom' => $c['ue_nom'],
                'statut' => $c['statut'],
                'typee' => [
                    'cours' => $c['cours'] ?? 0,
                    'td' => $c['td'] ?? 0,
                    'tp' => $c['tp'] ?? 0,
                                          ]

            ];
            
        }

        foreach ($groupes as $prof): ?>
            <tr class="<?= $prof['charge'] < 120 ? 'bg-danger-subtle' : '' ?>">
            <td class="<?= $prof['charge'] < 120 ? 'text-danger fw-bold' : '' ?>">
            <?= htmlspecialchars($prof['nom']) ?>
            </td>
            
             <td><?= htmlspecialchars($prof['prenom']) ?></td>
                <td><?= $prof['charge'] ?> h</td>
                <td>
                <?php foreach ($prof['nom_filiere'] as $fl): ?>   
                <div><?= htmlspecialchars($fl['nom_filiere']) ?></div>
            <?php endforeach; ?>
                </td>
                <td>
                <?php foreach ($prof['ues'] as $ue): ?>
                    <div class="d-flex align-items-center gap-2 mb-1">
                         
                        <?= htmlspecialchars($ue['nom']) ?>
                          : <?php
                                $types = [];
                                if (!empty($ue['typee']['cours'])) $types[] = 'Cours';
                                if (!empty($ue['typee']['td'])) $types[] = 'TD';
                                if (!empty($ue['typee']['tp'])) $types[] = 'TP';
                                echo htmlspecialchars(implode(', ', $types));
                                ?>

                        <small class="ms-2">
                            <?php if ($ue['statut'] === 'valide'): ?>
                                <span class="badge bg-success">Accepté</span>
                            <?php elseif ($ue['statut'] === 'refuse'): ?>
                                <span class="badge bg-danger">Refusé</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">En attente</span>
                            <?php endif; ?>
                        </small>
                        <form method="post" class="d-inline">
                            <input type="hidden" name="id_choix" value="<?= $ue['id_choix'] ?>">
                            <input type="hidden" name="action" value="valider">
                            <input type="hidden" name="annee_univ" value="<?= htmlspecialchars($annee_selectionnee) ?>">
                            <button type="submit" class="btn btn-sm btn-success">✓</button>
                        </form>
                        <form method="post"  class="d-inline">
                            <input type="hidden" name="id_choix" value="<?= $ue['id_choix'] ?>">
                            <input type="hidden" name="action" value="decliner">
                            <input type="hidden" name="annee_univ" value="<?= htmlspecialchars($annee_selectionnee) ?>">
                            <button type="submit" class="btn btn-sm btn-danger">✗</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </td>

            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>




</div>
    </div>
    <script>

       function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
  <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
    
