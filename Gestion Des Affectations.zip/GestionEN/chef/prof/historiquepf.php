<?php
session_start();
require_once '../../config/db.php'; // adapte le chemin si besoin


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}


/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}


/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
    transition: margin-left 0.3s ease;
}


    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }



        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
        .top-right-icon {
            position: absolute;
            top: 20px;
            right: 30px;
            }

        .top-right-icon img {
            width: 40px;
            height: 40px;
            cursor: pointer;
            transition: transform 0.3s;
            }

        .top-right-icon img:hover {
            transform: scale(1.2);

        }



        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="../accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="7" r="4"/>
        <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
      </svg>
      <a href="../UE_PF.php">Liste Professeur/UE</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
        <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
        <path d="M9 10h6"/>
        <path d="M9 14h6"/>
      </svg>
      <a href="../affectation.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="7" width="18" height="10" rx="2"/>
        <line x1="7" y1="11" x2="17" y2="11"/>
      </svg>
      <a href="../valid_decli.php">Valider le choix</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h16v2H4z"/>
        <path d="M4 8h16v2H4z"/>
        <path d="M4 12h16v2H4z"/>
        <path d="M4 16h16v2H4z"/>
      </svg>
      <a href="./chargeh.php">Charge horaire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 17l4-4-4-4M16 17V7"/>
      </svg>
      <a href="../vacant.php">UE vacantes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="../historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
    
    
     
    <div class="main-content">
   <div class="container mt-5">
    <h3 class="mb-4"><i class="fas fa-history me-2 text-primary"></i>Historique des Enseignements</h3>

        <!-- Filtre par année -->
    <form method="GET" class="mb-4 d-flex align-items-center gap-3">
        <label for="annee" class="form-label mb-0">Année universitaire :</label>
        <select name="annee" id="annee" class="form-select w-auto">
            <?php
            $annees = $conn->query("SELECT DISTINCT annee_universitaire FROM affectations ORDER BY annee_universitaire DESC")->fetchAll();
            foreach ($annees as $a) {
                $selected = ($_GET['annee'] ?? '') == $a['annee_universitaire'] ? 'selected' : '';
                echo "<option value='{$a['annee_universitaire']}' $selected>{$a['annee_universitaire']}</option>";
            }
            ?>
        </select>
        <button type="submit" class="btn btn-outline-primary"><i class="fas fa-filter"></i> Filtrer</button>
    </form>

<?php
    if (isset($_GET['annee'])):
        $annee_affectation = $_GET['annee'];  // format: 2024/2025
        $annee_choix = str_replace('/', '-', $annee_affectation);  // format pour table choix_professeurs : 2024-2025
        $id_prof = $_SESSION['user_id'];

        // Requête pour les choix (format avec tiret)
        $choix = $conn->prepare("SELECT ue.nom, c.cours, c.td, c.tp, c.statut 
            FROM choix_professeurs c 
            JOIN unites_enseignement ue ON c.id_ue = ue.id_ue 
            WHERE c.id_utilisateur = ? AND c.annee_universitaire = ?");
        $choix->execute([$id_prof, $annee_choix]);
        $choix_result = $choix->fetchAll();

        // Requête pour les affectations (format avec slash)
        $aff = $conn->prepare("SELECT ue.nom, a.cours, a.td, a.tp, a.date_affectation 
            FROM affectations a 
            JOIN unites_enseignement ue ON a.id_ue = ue.id_ue 
            WHERE a.id_utilisateur = ? AND a.annee_universitaire = ?");
        $aff->execute([$id_prof, $annee_affectation]);
        $aff_result = $aff->fetchAll();

        // Requête pour les notes (supposons qu'elles utilisent le format avec slash aussi)
        $notes = $conn->prepare("SELECT ue.nom, f.fichier, f.date_upload, f.type_session, f.annee_universitaire
            FROM notes f 
            JOIN unites_enseignement ue ON f.id_ue = ue.id_ue 
            WHERE f.id_utilisateur = ? AND f.annee_universitaire = ?");
        $notes->execute([$id_prof, $annee_affectation]);
        $notes_result = $notes->fetchAll();
?>
<!-- Ton HTML qui utilise $choix_result, $aff_result, $notes_result ici -->




    <div class="row g-4">
        <!-- Choix UEs -->
        <div class="col-md-4">
            <div class="card shadow-sm border-primary">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-list-alt me-2"></i>Choix de l'enseignant
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($choix_result as $c): ?>
                        <li class="list-group-item">
                        <strong><?= htmlspecialchars($c['nom']) ?></strong>
                        <div class="mt-1">
                            <?php
                                $types = [];
                                if ($c['cours']) $types[] = "Cours";
                                if ($c['td'])    $types[] = "TD";
                                if ($c['tp'])    $types[] = "TP";
                                echo implode(" / ", $types);
                            ?>
                            <span class="badge
                                <?= $c['statut'] === 'valide' ? 'bg-success' : ($c['statut'] === 'refuse' ? 'bg-danger' : 'bg-warning text-dark') ?> float-end">
                                <?= ucfirst($c['statut']) ?>
                            </span>
                        </div>
                    </li>

                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Modules affectés -->
        <div class="col-md-4">
            <div class="card shadow-sm border-success">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-chalkboard-teacher me-2"></i>Modules Affectés
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($aff_result as $a): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <?= htmlspecialchars($a['nom']) ?>
                                <small class="d-block text-muted">
                                    <?php
                                        $types = [];
                                        if ($a['cours']) $types[] = "Cours";
                                        if ($a['td'])    $types[] = "TD";
                                        if ($a['tp'])    $types[] = "TP";
                                        echo implode(" / ", $types);
                                    ?>
                                </small>
                            </div>
                            <span class="badge bg-light text-muted"><?= $a['date_affectation'] ?></span>
                        </li>

                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Fichiers notes -->
        <div class="col-md-4">
            <div class="card shadow-sm border-info">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-file-alt me-2"></i>Fichiers de Notes
                </div>
                <ul class="list-group list-group-flush">
                <?php foreach ($notes_result as $n): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <?= htmlspecialchars($n['nom']) ?><small >: <?= htmlspecialchars($n['type_session']) ?> </small>
                            <small class="d-block text-muted"><?= $n['date_upload'] ?>  </small>
                        </div>
                        <a href="<?= htmlspecialchars($n['fichier']) ?>" 
                        class="btn btn-sm btn-outline-success" 
                        download>
                        <i class="fas fa-download"></i> Télécharger
                        </a>
                    </li>
                <?php endforeach; ?>

                </ul>
            </div>
        </div>
    </div>
 <?php endif; ?>

</div>

    </div>
     <script>

             function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }


    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>
  <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
    
