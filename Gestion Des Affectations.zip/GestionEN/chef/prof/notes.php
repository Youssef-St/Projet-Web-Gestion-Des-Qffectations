<?php
session_start();
require_once '../../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$id_utilisateur = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    list($id_ue, $filiere_id) = explode("_", $_POST['id_ue_filiere']);
    $type_session = $_POST['session'];
    $annee = $_POST['annee_universitaire'];

    if (isset($_FILES['note_file']) && $_FILES['note_file']['error'] === UPLOAD_ERR_OK) {
        $filename = basename($_FILES['note_file']['name']);
        $target_dir = "../../uploads/notes/";
        $target_file = $target_dir . time() . "_" . $filename;

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        if (move_uploaded_file($_FILES['note_file']['tmp_name'], $target_file)) {
            $stmt = $conn->prepare("INSERT INTO notes (id_utilisateur, id_ue, type_session, fichier, annee_universitaire, filiere_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id_utilisateur, $id_ue, $type_session, $target_file, $annee, $filiere_id]);

            $message = "<div class='alert success'>✅ Notes uploadées avec succès.</div>";
        } else {
            $message = "<div class='alert error'>❌ Erreur lors de l'upload du fichier.</div>";
        }
    } else {
        $message = "<div class='alert error'>❌ Veuillez sélectionner un fichier valide.</div>";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Noto+Sans+JP:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
       <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
       <title>Plateforme e-Services</title>
    <style>
body {
  display: flex;
  background-color: #f0f2f5;
  margin: 0;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 230px;
  background: linear-gradient(180deg, rgb(83, 190, 34) 0%, rgb(83, 190, 34) 100%);
  color: white;
  padding: 25px 0;
  height: 100vh;
  transition: width 0.3s ease;
  overflow: hidden;
  position: fixed;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

.sidebar.collapsed {
  width: 60px;
}

.toggle-button {
  position: absolute;
  top: 10px;
  right: 15px;
  background-color: rgb(83, 190, 34);
  border: 0.1px solid rgb(83, 190, 34);
  border-radius: 4px;
  cursor: pointer;
  padding: 4px;
  z-index: 1000;
}

.logo-container {
  text-align: center;
  padding: 20px;
  transition: opacity 0.3s, height 0.3s;
}

.sidebar.collapsed .logo-container {
  opacity: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
}

.logo img {
  width: 100%;
  height: 120px;
  border-radius: 50%;
  margin: -25px auto;
  transition: transform 0.3s ease;
}

.logo img:hover {
  transform: scale(1.05);
}

.sidebar ul.menu {
  list-style: none;
  padding: 0;
  margin-top: 30px;
}

.sidebar ul.menu li {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  white-space: nowrap;
  transition: 0.3s;
  width: 100%;
  box-sizing: border-box;
}

.sidebar.collapsed ul.menu li {
  justify-content: center;
  padding: 12px 0;
}

.sidebar ul.menu li svg {
  margin-right: 10px;
  min-width: 20px;
}

.sidebar.collapsed ul.menu li a {
  display: none;
}

.sidebar ul.menu li a {
  text-decoration: none;
  color: #e0f2f1;
  font-size: 16px;
  transition: color 0.3s;
}

.sidebar ul.menu li a:hover {
  color: #ffffff;
}





/* Style moderne pour la section Fonctions Professeur */
.prof-menu-item {
  overflow: visible;
  flex-direction: column;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 12px 20px;
  box-shadow: 0 2px 8px 0 rgba(83,190,34,0.07);
  transition: background 0.2s, box-shadow 0.2s;
}

.prof-menu-item .dropdown-toggle {
  width: 100%;
  align-items: center;
  
  color: #e0f2f1;
  border-radius: 10px;
  transition: background 0.2s, color 0.2s;
  cursor: pointer;
  user-select: none;
  display: flex;
  background: none;
}

.prof-menu-item .dropdown-toggle:hover {
  background: rgba(83,190,34,0.15);
  color: #fff;
}

.prof-menu-item ul {
  padding-left: 0;
  margin: 0;
  width: 100%;
  background: rgba(255,255,255,0.13);
  border-radius: 0 0 12px 12px;
  box-shadow: 0 4px 18px 0 rgba(83,190,34,0.08);
  position: static;
  /* Correction taille */
  max-width: 100%;
  min-width: 0;
  max-height: 180px; /* Limite la hauteur */
  overflow-y: auto;
}

.prof-menu-item ul li {
  margin: 0;
  width: 100%;
}

.prof-link {
  display: flex;
  align-items: center;
  color: #e0f2f1;
  padding: 10px 20px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s, color 0.2s;
  margin-bottom: 2px;
  text-decoration: none;
  width: 100%;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.prof-link:hover {
  background: #53be22;
  color: #fff;
  text-decoration: none;
  transform: translateX(5px) scale(1.03);
}

.prof-link i {
  font-size: 1em;
  margin-right: 10px;
  color: #fff;
  opacity: 0.8;
}

.collapse:not(.show) {
  display: none;
}
.collapse.show {
  display: block;
}

/* Cache le texte "Professeur" quand la sidebar est réduite */
.sidebar.collapsed .prof-title {
  display: none;
}

/* Cache aussi le chevron */
.sidebar.collapsed .chevron {
  display: none;
}



/* Sidebar collapsed: cache le texte et la flèche du dropdown Professeur */
.sidebar.collapsed .prof-title,
.sidebar.collapsed .chevron {
  display: none !important;
}

/* Sidebar collapsed: centre l’icône Professeur */
.sidebar.collapsed .prof-icon {
  margin-left: 13px;
  display: flex;
  justify-content: center;
  width: 100%;
}

/* Sidebar collapsed: cache le sous-menu Professeur */
.sidebar.collapsed #profMenu {
  display: none !important;
}

/* ===== MAIN CONTENT ===== */
.main-content {
    flex-grow: 1;
    margin-left: 230px;
    padding: 30px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.05);
}
    .sidebar.collapsed ~ .main-content {
      margin-left: 60px;
    }


        /*===================================================0*/



.container {
    max-width: 800px;
    background: #ffffff;
    margin: 60px auto;
    padding: 40px 50px;
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
    position: relative;
    overflow: hidden;
    border-top: 6px solid #2e7d32;
}

h2 {
    text-align: center;
    color: #2e7d32;
    margin-bottom: 30px;
    font-size: 26px;
}

label {
    font-weight: 600;
    color: #444;
    margin-top: 20px;
    display: block;
}

select, input[type="text"], input[type="file"] {
    width: 100%;
    padding: 14px;
    margin-top: 10px;
    margin-bottom: 20px;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size: 15px;
    transition: 0.3s ease;
}

select:focus, input:focus {
    border-color: #2e7d32;
    outline: none;
    box-shadow: 0 0 0 3px rgba(46, 125, 50, 0.15);
}

button.ii {
    width: 100%;
    padding: 14px;
    background: #2e7d32;
    color: white;
    border: none;
    font-size: 16px;
    font-weight: bold;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.3s ease;
}

button.ii:hover {
    background: #1b5e20;
}

.alert {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-weight: 600;
    text-align: center;
}

.success {
    background-color: #d0f0d3;
    color: #1b5e20;
}

.error {
    background-color: #ffdddd;
    color: #c62828;
}

.top-right-icon {
    position: absolute;
    top: 20px;
    right: 30px;
}

.top-right-icon img {
    width: 36px;
    height: 36px;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.top-right-icon img:hover {
    transform: scale(1.2);
}

@media (max-width: 768px) {
    .container {
        margin: 30px 20px;
        padding: 30px 20px;
    }

    h2 {
        font-size: 22px;
    }
}



        </style>
</head>
<body>
   
<div class="sidebar" id="sidebar">
  <!-- Toggle button for collapse/expand -->
  <button class="toggle-button" onclick="toggleSidebar()">
    <svg id="toggleIcon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      <path id="toggleArrow" d="M9 3v18"/>
    </svg>
  </button>

  <!-- Logo section -->
  <div class="logo-container">
    <div class="logo">
      <a href="./accueil.php">
        <img src="../../images/logo1.png" alt="logo">
      </a>
    </div>
  </div>

  <ul class="menu">
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7"/>
        <path d="M9 22V12h6v10"/>
      </svg>
      <a href="../accueil.php">Accueil</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="7" r="4"/>
        <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
      </svg>
      <a href="../UE_PF.php">Liste Professeur/UE</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 2h6a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H9"/>
        <path d="M16 2v4H8a2 2 0 0 0-2 2v12"/>
        <path d="M9 10h6"/>
        <path d="M9 14h6"/>
      </svg>
      <a href="../affectation.php">Affectation</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="7" width="18" height="10" rx="2"/>
        <line x1="7" y1="11" x2="17" y2="11"/>
      </svg>
      <a href="../valid_decli.php">Valider le choix</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h16v2H4z"/>
        <path d="M4 8h16v2H4z"/>
        <path d="M4 12h16v2H4z"/>
        <path d="M4 16h16v2H4z"/>
      </svg>
      <a href="./chargeh.php">Charge horaire</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M8 17l4-4-4-4M16 17V7"/>
      </svg>
      <a href="../vacant.php">UE vacantes</a>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M2 12h7v7H2z"/>
        <path d="M15 3h7v7h-7z"/>
        <path d="M15 14h7v7h-7z"/>
      </svg>
      <a href="../historique.php">Historique</a>
    </li>
    <!-- Fonctions Professeur - Design Moderne -->
    <li class="prof-menu-item">
      <a class="dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="collapse" data-bs-target="#profMenu" aria-expanded="false">
        <span class="prof-icon">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
               stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="7" r="4"/>
            <path d="M6.5 21v-2a4.5 4.5 0 0 1 9 0v2"/>
          </svg>
        </span>
        <span class="prof-title">Professeur</span>

      </a>
      <ul id="profMenu" class="collapse list-unstyled">
        <li><a class="prof-link" href="./souhait.php"><i class="bi bi-star"></i>Souhait</a></li>
        <li><a class="prof-link" href="./notes.php"><i class="bi bi-journal-text"></i>Notes</a></li>
        <li><a class="prof-link" href="./historiquepf.php"><i class="bi bi-clock-history"></i>Historique</a></li>
      </ul>
    </li>
    <li>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="white"
           stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      <a href="../../login.php">Déconnexion</a>
    </li>
  </ul>
</div>
    
    
     
    <div class="main-content">
    <div class="container">
        <h2>📄 Uploader les Notes</h2>

        <?= $message ?>

        <form method="POST" enctype="multipart/form-data">
            <label for="id_ue_filiere">Unité d'enseignement / Filière :</label>
            <select name="id_ue_filiere" required>
                <option value="">-- Sélectionner une UE/Filière --</option>
                <?php
                $stmt = $conn->prepare("SELECT af.id_ue, af.id_filiere AS filiere_id, ue.nom AS ue_nom, f.nom_filiere 
                    FROM affectations af
                    JOIN unites_enseignement ue ON af.id_ue = ue.id_ue
                    JOIN filieres f ON af.id_filiere = f.id_filiere
                    WHERE af.id_utilisateur = ?");
                $stmt->execute([$id_utilisateur]);
                while ($row = $stmt->fetch()) {
                    $value = $row['id_ue'] . "_" . $row['filiere_id'];
                    $label = "{$row['ue_nom']} - {$row['nom_filiere']}";
                    echo "<option value='$value'>$label</option>";
                }
                ?>
            </select>

            <label for="session">Session :</label>
            <select name="session" required>
                <option value="normale">Session Normale</option>
                <option value="rattrapage">Session de Rattrapage</option>
            </select>
            
            <label for="ann">Année Universitaire :</label>
            <input type="text" name="annee_universitaire" placeholder="2024/2025" required>

            <label for="note_file">Fichier des Notes :</label>
            <input type="file" name="note_file" required>

            <button class = "ii" type="submit">📤 Uploader</button>
        </form>
    </div>
    </div>
    <script>

                 function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const arrow = document.getElementById('toggleArrow');

        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
        arrow.setAttribute("d", "M15 3v18"); // vers la gauche
        } else {
        arrow.setAttribute("d", "M9 3v18"); // vers la droite
        }
    }

    const currentPage = window.location.pathname.split('/').pop();
    const links = document.querySelectorAll(".nav-item ul li a");

    links.forEach(link => {
        const linkPage = link.getAttribute("href").split('/').pop();
        if (linkPage === currentPage) {
            link.parentElement.classList.add("active");
        }
    });
</script>

  <!-- JS Bootstrap et Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
    
